# BLACKWOOD: Lost Signal — consolidated source (UE 5.8)

A first-person survival horror prototype, rebuilt from earlier patches to fix the **missing player pawn, missing HUD and missing TAB inventory**. Its UI is built in C++: no Blueprint widget, Python fix script, or manual level GameMode override is required for starting the default map.

## Start (Windows)
1. Install UE 5.8 and Visual Studio with C++ and Windows SDK.
2. Open `BlackwoodSurvival.uproject` with UE 5.8 and rebuild the C++ module.
3. Select **Play** (not Simulate). The C++ main menu should appear; click **GRAJ**.
4. Press **WASD**, **TAB**, or **1–0**. Press **Esc** to reopen menu.
5. If content is installed, run `Scripts/SetupEditorAssets.py` once via **Tools → Execute Python Script** to import original audio and editor-generated materials.

### Important: optional third-party assets
This public repository contains the complete **game source, config and project definition**, but it does **not** redistribute third-party Fab assets (StyleHex forest), the Whisper package, or the Nulla/Free Fire character. These packs are in the user's previously assembled local project and can have third-party redistribution restrictions. If you already own them, copy your existing `Content/StyleHex_Studio`, `Content/Whisper`, and (if available) `Content/Blackwood/Player` folders into this project's `Content/` **without changing their internal paths**. Their original materials must be preserved.

Without those packs, the game still generates a prototype forest using built-in Unreal meshes; the optional creature is replaced by a fallback mesh. This fallback is not photorealistic.

## Controls
| Key | Action |
|---|---|
| WASD / mouse | Move / look |
| TAB | Open inventory |
| 1–0 | Choose one of ten hotbar slots |
| LMB | Use selected item / attack / shoot |
| R | Reload pistol when alive; respawn after death |
| E | Gather / interact |
| F | Flashlight |
| Shift / Ctrl / Space | Sprint / crouch / jump |
| V | Switch FPP/TPP (avatar model optional) |
| Esc | Show/hide main menu |

Starting loadout: axe, pickaxe, knife, **9mm pistol (12 + 36 rounds)**, spear and flashlight. Berries, water and campfire are collectible/craftable.

## Technical notes
- Boot map: `/Engine/Maps/Entry`, free of third-party per-level GameMode overrides.
- Gameplay: `ABWGameMode` assigns `ABWCharacter`, `ABWPlayerController`, and `ABWHUD`.
- `ABWPlayerController` shows a generated `UBWMainMenuWidget` and possesses the pawn when starting.
- `ABWWorldDirector` generates world and gameplay at runtime; optional existing StyleHex assets load by exact game paths.
- Check stdout / Output Log for `BLACKWOOD_BOOT`.
- Run `python Scripts/StaticCheck.py` for offline structural checks. This does **not** compile the Unreal C++ code.

## Build Windows EXE
1. Ensure UE 5.8, Visual Studio C++ tools, and the Windows SDK are installed.
2. Double-click `BUILD_WINDOWS.cmd`, or in UE: **Platforms → Windows → Package Project**.
3. The produced EXE and cooked game files are in the `Packaged` directory. The EXE alone is not the whole distributable; keep the generated files together.

**Status:** Source integrated and structurally checked, but **not compiled or play-tested under Unreal Engine here**. Please review the local build log if the editor reports errors; the documentation does not claim a working Windows EXE.
