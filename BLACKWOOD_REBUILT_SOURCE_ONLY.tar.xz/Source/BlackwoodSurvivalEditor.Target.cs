using UnrealBuildTool;
using System.Collections.Generic;

public class BlackwoodSurvivalEditorTarget : TargetRules
{
    public BlackwoodSurvivalEditorTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Editor;
        DefaultBuildSettings = BuildSettingsVersion.V7;
        IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
        ExtraModuleNames.Add("BlackwoodSurvival");
    }
}
