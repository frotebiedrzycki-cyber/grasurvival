#include "BWPickup.h"
#include "BWVisuals.h"
#include "Components/SceneComponent.h"
#include "Components/StaticMeshComponent.h"

ABWPickup::ABWPickup()
{
    PrimaryActorTick.bCanEverTick = false;
    Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
    RootComponent = Root;
    Mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PickupMesh"));
    Mesh->SetupAttachment(Root);
    Mesh->SetCollisionProfileName(TEXT("BlockAll"));
}

void ABWPickup::Configure(EBWPickupType InType)
{
    PickupType = InType;
    Mesh->SetStaticMesh(BWVisuals::Mesh(InType == EBWPickupType::Berries ? TEXT("Sphere") : TEXT("Cylinder")));
    Mesh->SetRelativeLocation(FVector(0,0,33));
    Mesh->SetRelativeScale3D(InType == EBWPickupType::Berries ? FVector(0.5f) : FVector(0.3f,0.3f,0.65f));
    BWVisuals::Tint(Mesh, InType == EBWPickupType::Berries ? FLinearColor(0.40f,0.05f,0.10f) : FLinearColor(0.09f,0.35f,0.5f));
}

FString ABWPickup::Prompt() const
{
    return PickupType == EBWPickupType::Berries ? TEXT("[E] Zbierz jagody") : TEXT("[E] Podnies wode");
}
