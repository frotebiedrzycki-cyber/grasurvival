#include "BWMainMenuWidget.h"
#include "BWPlayerController.h"
#include "Blueprint/WidgetTree.h"
#include "Components/CanvasPanel.h"
#include "Components/CanvasPanelSlot.h"
#include "Components/VerticalBox.h"
#include "Components/VerticalBoxSlot.h"
#include "Components/Border.h"
#include "Components/Button.h"
#include "Components/TextBlock.h"
#include "GameFramework/PlayerController.h"

void UBWMainMenuWidget::NativeOnInitialized()
{
    Super::NativeOnInitialized();
    if (!WidgetTree) return;
    if (WidgetTree->RootWidget) return;

    UCanvasPanel* Root = WidgetTree->ConstructWidget<UCanvasPanel>(UCanvasPanel::StaticClass(), TEXT("RootCanvas"));
    WidgetTree->RootWidget = Root;

    UBorder* Backdrop = WidgetTree->ConstructWidget<UBorder>(UBorder::StaticClass(), TEXT("Backdrop"));
    Backdrop->SetBrushColor(FLinearColor(0.007f, 0.017f, 0.024f, 0.97f));
    UCanvasPanelSlot* BG = Root->AddChildToCanvas(Backdrop);
    BG->SetAnchors(FAnchors(0.f,0.f,1.f,1.f));
    BG->SetOffsets(FMargin(0.f));

    UVerticalBox* Column = WidgetTree->ConstructWidget<UVerticalBox>(UVerticalBox::StaticClass(), TEXT("MenuPanel"));
    UCanvasPanelSlot* Panel = Root->AddChildToCanvas(Column);
    Panel->SetAnchors(FAnchors(0.5f,0.5f));
    Panel->SetAlignment(FVector2D(0.5f,0.5f));
    Panel->SetAutoSize(true);

    auto MakeText = [&](const FString& Value, const FLinearColor& Tint, float Padding)
    {
        UTextBlock* T = WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass());
        T->SetText(FText::FromString(Value));
        T->SetColorAndOpacity(FSlateColor(Tint));
        if (UVerticalBoxSlot* Slot = Column->AddChildToVerticalBox(T))
        {
            Slot->SetPadding(FMargin(8.f, Padding));
            Slot->SetHorizontalAlignment(HAlign_Center);
        }
    };

    MakeText(TEXT("B L A C K W O O D"), FLinearColor(.92f,.92f,.86f), 18.f);
    MakeText(TEXT("LOST SIGNAL   /   SURVIVAL HORROR"), FLinearColor(.64f,.72f,.73f), 9.f);
    MakeText(TEXT("Cisza nie oznacza bezpieczenstwa."), FLinearColor(.48f,.56f,.58f), 18.f);

    auto MakeButton = [&](const FString& Label) -> UButton*
    {
        UButton* Button = WidgetTree->ConstructWidget<UButton>(UButton::StaticClass());
        Button->SetBackgroundColor(FLinearColor(.12f,.25f,.26f));
        UTextBlock* Text = WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass());
        Text->SetText(FText::FromString(Label));
        Text->SetColorAndOpacity(FSlateColor(FLinearColor(.97f,.96f,.88f)));
        Text->SetJustification(ETextJustify::Center);
        Button->AddChild(Text);
        if (UVerticalBoxSlot* Slot = Column->AddChildToVerticalBox(Button))
        {
            Slot->SetPadding(FMargin(10.f, 12.f));
            Slot->SetHorizontalAlignment(HAlign_Fill);
        }
        return Button;
    };

    UButton* Play = MakeButton(TEXT("GRAJ / KONTYNUUJ"));
    Play->OnClicked.AddDynamic(this, &UBWMainMenuWidget::HandlePlay);
    UButton* Quit = MakeButton(TEXT("WYJSCIE"));
    Quit->OnClicked.AddDynamic(this, &UBWMainMenuWidget::HandleQuit);
    MakeText(TEXT("WASD: ruch   |   TAB: ekwipunek   |   1-0: pasek   |   ESC: menu"),
        FLinearColor(.52f,.62f,.64f), 26.f);
}

void UBWMainMenuWidget::HandlePlay()
{
    if (ABWPlayerController* PC = Cast<ABWPlayerController>(GetOwningPlayer())) PC->StartGame();
}

void UBWMainMenuWidget::HandleQuit()
{
    if (ABWPlayerController* PC = Cast<ABWPlayerController>(GetOwningPlayer())) PC->QuitGame();
}
