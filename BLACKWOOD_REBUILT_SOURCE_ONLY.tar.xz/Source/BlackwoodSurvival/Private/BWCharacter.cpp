#include "BWCharacter.h"
#include "BWResourceNode.h"
#include "BWPickup.h"
#include "BWCampfire.h"
#include "BWRadio.h"
#include "BWWatcher.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Engine/StaticMesh.h"
#include "Components/CapsuleComponent.h"
#include "Components/InputComponent.h"
#include "Components/SpotLightComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "Sound/SoundBase.h"
#include "BWVisuals.h"
#include "Components/StaticMeshComponent.h"
#include "Components/PointLightComponent.h"

namespace
{
    void BWPlay2D(UObject* WorldContext, const TCHAR* Path, float Volume = 1.0f, float Pitch = 1.0f)
    {
        if (!WorldContext) return;
        if (USoundBase* Sound = LoadObject<USoundBase>(nullptr, Path))
        {
            UGameplayStatics::PlaySound2D(WorldContext, Sound, Volume, Pitch);
        }
    }

    void BWPlayAtLocation(UObject* WorldContext, const FVector& Location, const TCHAR* Path, float Volume = 1.0f, float Pitch = 1.0f)
    {
        if (!WorldContext) return;
        if (USoundBase* Sound = LoadObject<USoundBase>(nullptr, Path))
        {
            UGameplayStatics::PlaySoundAtLocation(WorldContext, Sound, Location, Volume, Pitch);
        }
    }
}

ABWCharacter::ABWCharacter()
{
    PrimaryActorTick.bCanEverTick = true;
    GetCapsuleComponent()->InitCapsuleSize(42.f,90.f);
    CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
    CameraBoom->SetupAttachment(GetCapsuleComponent());
    CameraBoom->SetRelativeLocation(FVector(0.f,0.f,72.f));
    CameraBoom->TargetArmLength = 0.f;
    CameraBoom->bUsePawnControlRotation = true;
    CameraBoom->bDoCollisionTest = true;

    Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("FirstPersonCamera"));
    Camera->SetupAttachment(CameraBoom, USpringArmComponent::SocketName);
    Camera->SetRelativeLocation(FVector::ZeroVector);
    Camera->bUsePawnControlRotation = false;
    Camera->SetFieldOfView(90.f);

    CharacterDisplay = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("NullaBody"));
    CharacterDisplay->SetupAttachment(GetCapsuleComponent());
    CharacterDisplay->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    CharacterDisplay->SetGenerateOverlapEvents(false);
    CharacterDisplay->SetCastShadow(true);
    CharacterDisplay->SetVisibility(false);

    Flashlight = CreateDefaultSubobject<USpotLightComponent>(TEXT("Flashlight"));
    Flashlight->SetupAttachment(Camera);
    Flashlight->SetRelativeLocation(FVector(14,11,-7));
    Flashlight->SetIntensity(24000.f);
    Flashlight->SetAttenuationRadius(2900.f);
    Flashlight->SetInnerConeAngle(13.f);
    Flashlight->SetOuterConeAngle(29.f);
    Flashlight->SetLightColor(FLinearColor(.78f,.88f,1.f));
    Flashlight->SetVisibility(false);
    Flashlight->SetCastShadows(true);

    ToolHandle = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("HeldToolHandle"));
    ToolHandle->SetupAttachment(Camera);
    ToolHandle->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    ToolHandle->SetCastShadow(false);
    ToolHead = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("HeldToolHead"));
    ToolHead->SetupAttachment(Camera);
    ToolHead->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    ToolHead->SetCastShadow(false);
    MuzzleFlash = CreateDefaultSubobject<UPointLightComponent>(TEXT("PistolMuzzleFlash"));
    MuzzleFlash->SetupAttachment(Camera);
    MuzzleFlash->SetRelativeLocation(FVector(72.f,22.f,-11.f));
    MuzzleFlash->SetLightColor(FLinearColor(1.f,.58f,.18f));
    MuzzleFlash->SetIntensity(5500.f);
    MuzzleFlash->SetAttenuationRadius(280.f);
    MuzzleFlash->SetCastShadows(false);
    MuzzleFlash->SetVisibility(false);

    bUseControllerRotationYaw = true;
    GetCharacterMovement()->bOrientRotationToMovement = false;
    GetCharacterMovement()->MaxWalkSpeed = 370.f;
    GetCharacterMovement()->MaxWalkSpeedCrouched = 170.f;
    GetCharacterMovement()->JumpZVelocity = 410.f;
    GetCharacterMovement()->AirControl = 0.25f;
    GetCharacterMovement()->GetNavAgentPropertiesRef().bCanCrouch = true;
}

void ABWCharacter::BeginPlay()
{
    Super::BeginPlay();
    // Do not teleport to (0,0,180)! BWGameMode v0.5.2 already chooses a safe
    // position based on the actual landscape. The old teleport broke BW_PlayableForest.
    SafeRespawnLocation = GetActorLocation();
    ToolHandle->SetStaticMesh(BWVisuals::Mesh(TEXT("Cylinder")));
    ToolHead->SetStaticMesh(BWVisuals::Mesh(TEXT("Cube")));

    // Nulla is a static mesh (no rig/skeleton). Its size is adjusted to the capsule.
    if (UStaticMesh* NullaMesh = LoadObject<UStaticMesh>(nullptr,
        TEXT("/Game/Blackwood/Player/SM_Nulla.SM_Nulla")))
    {
        CharacterDisplay->SetStaticMesh(NullaMesh);
        const FBoxSphereBounds Bounds = NullaMesh->GetBounds();
        const float MeshHeight = FMath::Max(1.f, Bounds.BoxExtent.Z * 2.f);
        const float Scale = FMath::Clamp(170.f / MeshHeight, 0.01f, 10.f);
        CharacterDisplay->SetRelativeScale3D(FVector(Scale));
        const float Bottom = (Bounds.Origin.Z - Bounds.BoxExtent.Z) * Scale;
        CharacterDisplay->SetRelativeLocation(FVector(0.f, 0.f, -GetCapsuleComponent()->GetScaledCapsuleHalfHeight() - Bottom));
        CharacterDisplay->SetVisibility(bThirdPerson);
        UE_LOG(LogTemp, Display, TEXT("BLACKWOOD NULLA: player mesh ready, scale %.3f"), Scale);
    }
    else
    {
        // Without the optional imported avatar, default to FPP so the camera remains playable.
        bThirdPerson = false;
        CameraBoom->TargetArmLength = 0.f;
        CameraBoom->SetRelativeLocation(FVector(0.f,0.f,69.f));
        UE_LOG(LogTemp, Warning, TEXT("BLACKWOOD NULLA: avatar unavailable; using safe first-person camera"));
    }
    UpdateHeldTool();
    Notify(TEXT("BLACKWOOD: V kamera TPP/FPP | TAB plecak | 1-0 bron/narzedzia"), 8.f);
}

void ABWCharacter::Tick(float Dt)
{
    Super::Tick(Dt);
    if (bDead) return;

    MessageDuration = FMath::Max(0.f, MessageDuration - Dt);
    AttackCooldown = FMath::Max(0.f, AttackCooldown - Dt);
    MuzzleFlashRemaining = FMath::Max(0.f, MuzzleFlashRemaining - Dt);
    if (MuzzleFlashRemaining <= 0.f && MuzzleFlash)
        MuzzleFlash->SetVisibility(false);
    if (ReloadRemaining > 0.f)
    {
        ReloadRemaining -= Dt;
        if (ReloadRemaining <= 0.f)
        {
            ReloadRemaining = 0.f;
            const int32 Transfer = FMath::Min(12 - AmmoInMagazine, ReserveAmmo);
            AmmoInMagazine += Transfer;
            ReserveAmmo -= Transfer;
            Notify(FString::Printf(TEXT("Pistolet przeladowany: %d / %d"), AmmoInMagazine, ReserveAmmo), 1.8f);
        }
    }
    Hunger = FMath::Max(0.f, Hunger - 0.22f * Dt);
    Thirst = FMath::Max(0.f, Thirst - 0.36f * Dt);
    if (Hunger <= 0.f || Thirst <= 0.f) TakeSurvivalDamage(3.5f * Dt);

    const bool bMoving = GetVelocity().SizeSquared2D() > 2000.f;
    if (bSprinting && bMoving && Stamina > 0.f && !bIsCrouched)
        Stamina = FMath::Max(0.f, Stamina - 18.f * Dt);
    else
        Stamina = FMath::Min(100.f, Stamina + 14.f * Dt);
    GetCharacterMovement()->MaxWalkSpeed = bSprinting && Stamina > 1.f && !bIsCrouched ? 640.f : 370.f;

    for (TActorIterator<ABWCampfire> Fire(GetWorld()); Fire; ++Fire)
    {
        if (FVector::Dist2D(GetActorLocation(), Fire->GetActorLocation()) < 430.f)
        {
            Health = FMath::Min(100.f, Health + 0.9f * Dt);
            Stamina = FMath::Min(100.f, Stamina + 12.f * Dt);
            break;
        }
    }

    if (bFlashlightOn)
    {
        Battery = FMath::Max(0.f, Battery - 0.24f * Dt);
        const float BaseIntensity = Battery < 18.f ? 17000.f : 24000.f;
        const float Flicker = Battery < 18.f ? (0.78f + 0.22f * FMath::Sin(GetWorld()->GetTimeSeconds() * 23.f)) : 1.0f;
        Flashlight->SetIntensity(BaseIntensity * Flicker);
        if (Battery <= 0.f)
        {
            bFlashlightOn = false;
            Flashlight->SetVisibility(false);
            Notify(TEXT("Bateria latarki wyczerpana."));
            BWPlay2D(this, TEXT("/Game/Audio/blackwood_flashlight_click.blackwood_flashlight_click"), 0.6f, 0.85f);
        }
    }
    else
    {
        Battery = FMath::Min(100.f, Battery + 0.10f * Dt);
        Flashlight->SetIntensity(24000.f);
    }
}

void ABWCharacter::SetupPlayerInputComponent(UInputComponent* IC)
{
    Super::SetupPlayerInputComponent(IC);
    IC->BindAxis(TEXT("MoveForward"),this,&ABWCharacter::Forward);
    IC->BindAxis(TEXT("MoveRight"),this,&ABWCharacter::Right);
    IC->BindAxis(TEXT("Turn"),this,&ABWCharacter::Turn);
    IC->BindAxis(TEXT("LookUp"),this,&ABWCharacter::Look);
    IC->BindAction(TEXT("Jump"),IE_Pressed,this,&ACharacter::Jump);
    IC->BindAction(TEXT("Jump"),IE_Released,this,&ACharacter::StopJumping);
    IC->BindAction(TEXT("Sprint"),IE_Pressed,this,&ABWCharacter::StartSprint);
    IC->BindAction(TEXT("Sprint"),IE_Released,this,&ABWCharacter::StopSprint);
    IC->BindAction(TEXT("Crouch"),IE_Pressed,this,&ABWCharacter::ToggleCrouch);
    IC->BindAction(TEXT("Flashlight"),IE_Pressed,this,&ABWCharacter::ToggleFlashlight);
    IC->BindAction(TEXT("Inventory"),IE_Pressed,this,&ABWCharacter::ToggleInventory);
    IC->BindAction(TEXT("CameraMode"),IE_Pressed,this,&ABWCharacter::ToggleCameraMode);
    IC->BindAction(TEXT("Interact"),IE_Pressed,this,&ABWCharacter::Interact);
    IC->BindAction(TEXT("Attack"),IE_Pressed,this,&ABWCharacter::Attack);
    IC->BindAction(TEXT("Respawn"),IE_Pressed,this,&ABWCharacter::Respawn);
    IC->BindAction(TEXT("Hotbar1"),IE_Pressed,this,&ABWCharacter::Hotbar1);
    IC->BindAction(TEXT("Hotbar2"),IE_Pressed,this,&ABWCharacter::Hotbar2);
    IC->BindAction(TEXT("Hotbar3"),IE_Pressed,this,&ABWCharacter::Hotbar3);
    IC->BindAction(TEXT("Hotbar4"),IE_Pressed,this,&ABWCharacter::Hotbar4);
    IC->BindAction(TEXT("Hotbar5"),IE_Pressed,this,&ABWCharacter::Hotbar5);
    IC->BindAction(TEXT("Hotbar6"),IE_Pressed,this,&ABWCharacter::Hotbar6);
    IC->BindAction(TEXT("Hotbar7"),IE_Pressed,this,&ABWCharacter::Hotbar7);
    IC->BindAction(TEXT("Hotbar8"),IE_Pressed,this,&ABWCharacter::Hotbar8);
    IC->BindAction(TEXT("Hotbar9"),IE_Pressed,this,&ABWCharacter::Hotbar9);
    IC->BindAction(TEXT("Hotbar0"),IE_Pressed,this,&ABWCharacter::Hotbar0);
}


FString ABWCharacter::GetHotbarItemName(int32 Index) const
{
    static const TCHAR* Names[] = {
        TEXT("SIEKIERA"), TEXT("KILOF"), TEXT("NOZ"), TEXT("PISTOLET"), TEXT("DZIDA"),
        TEXT("LATARKA"), TEXT("JAGODY"), TEXT("WODA"), TEXT("OGNISKO"), TEXT("RECE")
    };
    return Index >= 0 && Index < 10 ? FString(Names[Index]) : FString();
}

int32 ABWCharacter::GetHotbarItemCount(int32 Index) const
{
    if (Index == 6) return Berries;
    if (Index == 7) return Water;
    if (Index == 8) return FMath::Min(Wood / 5, Stone / 3);
    return 1;
}

bool ABWCharacter::HasHotbarItem(int32 Index) const
{
    return Index >= 0 && Index < 10 && GetHotbarItemCount(Index) > 0;
}

void ABWCharacter::SelectHotbar(int32 Index)
{
    if (bDead || Index < 0 || Index >= 10) return;
    SelectedHotbarSlot = Index;
    UpdateHeldTool();
    Notify(FString::Printf(TEXT("Wybrano: %s"), *GetHotbarItemName(Index)), 1.5f);
}

void ABWCharacter::Hotbar1() { SelectHotbar(0); }
void ABWCharacter::Hotbar2() { SelectHotbar(1); }
void ABWCharacter::Hotbar3() { SelectHotbar(2); }
void ABWCharacter::Hotbar4() { SelectHotbar(3); }
void ABWCharacter::Hotbar5() { SelectHotbar(4); }
void ABWCharacter::Hotbar6() { SelectHotbar(5); }
void ABWCharacter::Hotbar7() { SelectHotbar(6); }
void ABWCharacter::Hotbar8() { SelectHotbar(7); }
void ABWCharacter::Hotbar9() { SelectHotbar(8); }
void ABWCharacter::Hotbar0() { SelectHotbar(9); }

void ABWCharacter::UpdateHeldTool()
{
    if (!ToolHandle || !ToolHead) return;
    const bool bTool = SelectedHotbarSlot <= 4 || SelectedHotbarSlot == 5;
    ToolHandle->SetVisibility(bTool && !bThirdPerson);
    ToolHead->SetVisibility(bTool && !bThirdPerson);
    if (!bTool) return;

    // Small placeholder equipment drawn in first person; these are NOT final authored weapon models.
    ToolHandle->SetStaticMesh(BWVisuals::Mesh(TEXT("Cylinder")));
    ToolHandle->SetRelativeLocation(FVector(38.f,27.f,-34.f));
    ToolHandle->SetRelativeRotation(FRotator(10.f,0.f,0.f));
    ToolHandle->SetRelativeScale3D(FVector(.075f,.075f,.63f));
    ToolHead->SetRelativeLocation(FVector(38.f,27.f,-4.f));
    ToolHead->SetRelativeRotation(FRotator::ZeroRotator);
    ToolHead->SetRelativeScale3D(FVector(.42f,.12f,.16f));
    FLinearColor HeadColor(.28f,.34f,.38f);
    if (SelectedHotbarSlot == 1) // pickaxe
        ToolHead->SetRelativeScale3D(FVector(.75f,.12f,.14f));
    else if (SelectedHotbarSlot == 2) // knife
    {
        ToolHandle->SetRelativeScale3D(FVector(.07f,.07f,.36f));
        ToolHead->SetRelativeScale3D(FVector(.12f,.08f,.32f));
        ToolHead->SetRelativeLocation(FVector(39.f,27.f,-6.f));
    }
    else if (SelectedHotbarSlot == 3) // basic 9mm pistol
    {
        ToolHandle->SetStaticMesh(BWVisuals::Mesh(TEXT("Cube")));
        ToolHandle->SetRelativeLocation(FVector(40.f,23.f,-23.f));
        ToolHandle->SetRelativeRotation(FRotator(0.f,0.f,-18.f));
        ToolHandle->SetRelativeScale3D(FVector(.12f,.105f,.29f));
        ToolHead->SetStaticMesh(BWVisuals::Mesh(TEXT("Cube")));
        ToolHead->SetRelativeLocation(FVector(49.f,22.f,-11.f));
        ToolHead->SetRelativeRotation(FRotator::ZeroRotator);
        ToolHead->SetRelativeScale3D(FVector(.48f,.13f,.15f));
        HeadColor = FLinearColor(.13f,.16f,.19f);
    }
    else if (SelectedHotbarSlot == 4) // spear
    {
        ToolHandle->SetRelativeScale3D(FVector(.07f,.07f,1.15f));
        ToolHead->SetRelativeScale3D(FVector(.13f,.11f,.30f));
        ToolHead->SetRelativeLocation(FVector(39.f,27.f,15.f));
    }
    else if (SelectedHotbarSlot == 5) // flashlight
    {
        ToolHandle->SetRelativeScale3D(FVector(.13f,.13f,.43f));
        ToolHead->SetStaticMesh(BWVisuals::Mesh(TEXT("Cylinder")));
        ToolHead->SetRelativeScale3D(FVector(.20f,.20f,.075f));
        ToolHead->SetRelativeLocation(FVector(38.f,27.f,-10.f));
        HeadColor = FLinearColor(.20f,.25f,.31f);
    }
    else
        ToolHead->SetStaticMesh(BWVisuals::Mesh(TEXT("Cube")));

    if (SelectedHotbarSlot != 5)
        ToolHead->SetStaticMesh(BWVisuals::Mesh(TEXT("Cube")));
    BWVisuals::Tint(ToolHandle, FLinearColor(.20f,.12f,.07f));
    BWVisuals::Tint(ToolHead, HeadColor);
}

void ABWCharacter::Forward(float Amount)
{
    if (!bDead && Controller && !FMath::IsNearlyZero(Amount))
    {
        const FRotator Yaw(0.f,Controller->GetControlRotation().Yaw,0.f);
        AddMovementInput(FRotationMatrix(Yaw).GetUnitAxis(EAxis::X),Amount);
    }
}
void ABWCharacter::Right(float Amount)
{
    if (!bDead && Controller && !FMath::IsNearlyZero(Amount))
    {
        const FRotator Yaw(0.f,Controller->GetControlRotation().Yaw,0.f);
        AddMovementInput(FRotationMatrix(Yaw).GetUnitAxis(EAxis::Y),Amount);
    }
}
void ABWCharacter::Turn(float Amount) { if(!bDead) AddControllerYawInput(Amount); }
void ABWCharacter::Look(float Amount) { if(!bDead) AddControllerPitchInput(Amount); }
void ABWCharacter::StartSprint() { bSprinting = true; }
void ABWCharacter::StopSprint() { bSprinting = false; }
void ABWCharacter::ToggleCrouch() { if (bDead) return; if (bIsCrouched) UnCrouch(); else Crouch(); }
void ABWCharacter::ToggleInventory() { if (!bDead) bInventory = !bInventory; }
void ABWCharacter::ToggleCameraMode()
{
    bThirdPerson = !bThirdPerson;
    CameraBoom->TargetArmLength = bThirdPerson ? 285.f : 0.f;
    CameraBoom->SetRelativeLocation(FVector(0.f, 0.f, bThirdPerson ? 72.f : 69.f));
    if (CharacterDisplay) CharacterDisplay->SetVisibility(bThirdPerson && CharacterDisplay->GetStaticMesh() != nullptr);
    UpdateHeldTool();
    Notify(bThirdPerson ? TEXT("Kamera: TPP") : TEXT("Kamera: FPP"), 2.f);
}
FVector ABWCharacter::GetViewForward() const { return Camera->GetForwardVector(); }

void ABWCharacter::ToggleFlashlight()
{
    if (bDead) return;
    if (!bFlashlightOn && Battery <= 1.f) { Notify(TEXT("Brak energii latarki.")); return; }
    bFlashlightOn = !bFlashlightOn;
    Flashlight->SetVisibility(bFlashlightOn);
    BWPlay2D(this, TEXT("/Game/Audio/blackwood_flashlight_click.blackwood_flashlight_click"), 0.72f, bFlashlightOn ? 1.05f : 0.95f);
}

AActor* ABWCharacter::TraceLook(float Range) const
{
    if (!GetWorld()) return nullptr;
    const FVector Start = Camera->GetComponentLocation();
    const float CameraOffset = FVector::Dist(Start, GetActorLocation());
    const FVector End = Start + Camera->GetForwardVector() * (Range + (bThirdPerson ? CameraOffset : 0.f));
    FHitResult Hit;
    FCollisionQueryParams Params(SCENE_QUERY_STAT(BWInteractionTrace),false,this);
    return GetWorld()->LineTraceSingleByChannel(Hit,Start,End,ECC_Visibility,Params)
        ? Hit.GetActor() : nullptr;
}

FString ABWCharacter::GetInteractionPrompt() const
{
    if (bDead) return TEXT("[R] Wroc do zycia");
    if (AActor* Hit = TraceLook(360.f))
    {
        if (const ABWResourceNode* Node = Cast<ABWResourceNode>(Hit)) return Node->Prompt();
        if (const ABWPickup* Item = Cast<ABWPickup>(Hit)) return Item->Prompt();
        if (const ABWRadio* Radio = Cast<ABWRadio>(Hit)) return Radio->Prompt();
    }
    return TEXT("");
}

void ABWCharacter::Interact()
{
    if (bDead) return;
    AActor* Hit = TraceLook(360.f);
    if (ABWResourceNode* Node = Cast<ABWResourceNode>(Hit))
    {
        const FVector NodeLocation = Node->GetActorLocation();
        EBWResourceType Resource;
        if (Node->Harvest(Resource))
        {
            if (Resource == EBWResourceType::Wood)
            {
                const int32 Gain = SelectedHotbarSlot == 0 ? 2 : 1;
                Wood += Gain;
                Notify(FString::Printf(TEXT("+%d drewno"), Gain),1.5f);
            }
            else
            {
                const int32 Gain = SelectedHotbarSlot == 1 ? 2 : 1;
                Stone += Gain;
                Notify(FString::Printf(TEXT("+%d kamien"), Gain),1.5f);
            }
            BWPlayAtLocation(this, NodeLocation, TEXT("/Game/Audio/blackwood_pickup.blackwood_pickup"), 0.6f, 0.95f);
        }
    }
    else if (ABWPickup* Item = Cast<ABWPickup>(Hit))
    {
        if (Item->GetPickupType() == EBWPickupType::Berries) { Berries++; Notify(TEXT("+1 jagody")); }
        else { Water++; Notify(TEXT("+1 woda")); }
        BWPlayAtLocation(this, Item->GetActorLocation(), TEXT("/Game/Audio/blackwood_pickup.blackwood_pickup"), 0.7f, 1.05f);
        Item->Destroy();
    }
    else if (ABWRadio* Radio = Cast<ABWRadio>(Hit))
    {
        if (Radio->IsRepaired())
        {
            Notify(TEXT("Sygnal SOS zostal wyslany."),5.f);
            return;
        }
        if (Wood >= 8 && Stone >= 5)
        {
            Wood -= 8; Stone -= 5; Radio->SetRepaired(); bRadioRepaired = true;
            BWPlay2D(this, TEXT("/Game/Audio/blackwood_radio_fixed.blackwood_radio_fixed"), 0.75f, 1.0f);
            Notify(TEXT("SYGNAL WYSLANY! Pierwsza misja zakonczona."),12.f);
        }
        else Notify(FString::Printf(TEXT("Brakuje: drewno %d, kamien %d"),FMath::Max(0,8-Wood),FMath::Max(0,5-Stone)),5.f);
    }
}

void ABWCharacter::Attack()
{
    if (bDead || bInventory) return;

    if (SelectedHotbarSlot == 3) { FirePistol(); return; }
    if (SelectedHotbarSlot == 5) { ToggleFlashlight(); return; }
    if (SelectedHotbarSlot == 6) { Eat(); return; }
    if (SelectedHotbarSlot == 7) { Drink(); return; }
    if (SelectedHotbarSlot == 8) { BuildCampfire(); return; }

    if (AttackCooldown > 0.f || Stamina < 10.f) return;
    const float Reach = SelectedHotbarSlot == 4 ? 400.f : 265.f;
    const int32 Damage = SelectedHotbarSlot == 9 ? 1 : 2;
    AttackCooldown = 0.72f;
    Stamina -= 13.f;
    BWPlay2D(this, TEXT("/Game/Audio/blackwood_attack.blackwood_attack"), 0.60f, 1.0f);
    if (ABWWatcher* Enemy = Cast<ABWWatcher>(TraceLook(Reach)))
    {
        // An enemy may Destroy() itself during ReceiveMeleeHit, so validate before each hit.
        TWeakObjectPtr<ABWWatcher> SafeEnemy(Enemy);
        for (int32 i=0; i<Damage && SafeEnemy.IsValid(); ++i)
            SafeEnemy->ReceiveMeleeHit();
        Notify(FString::Printf(TEXT("Trafienie! Obrazenia: %d"), Damage), 1.4f);
    }
}

void ABWCharacter::ReloadPistol()
{
    if (bDead || SelectedHotbarSlot != 3) return;
    if (ReloadRemaining > 0.f) return;
    if (AmmoInMagazine >= 12)
    {
        Notify(TEXT("Magazynek jest pelny."), 1.5f);
        return;
    }
    if (ReserveAmmo <= 0)
    {
        Notify(TEXT("Brak zapasowej amunicji 9 mm."), 2.3f);
        return;
    }
    ReloadRemaining = 1.35f;
    BWPlay2D(this, TEXT("/Game/Audio/blackwood_pistol_reload.blackwood_pistol_reload"), .78f);
    Notify(TEXT("Przeladowywanie pistoletu..."), 1.35f);
}

void ABWCharacter::FirePistol()
{
    if (bDead || bInventory || SelectedHotbarSlot != 3) return;
    if (ReloadRemaining > 0.f || AttackCooldown > 0.f) return;
    if (AmmoInMagazine <= 0)
    {
        Notify(TEXT("Pusty magazynek! R - przeladuj."), 1.9f);
        BWPlay2D(this, TEXT("/Game/Audio/blackwood_flashlight_click.blackwood_flashlight_click"), .35f, .75f);
        return;
    }

    --AmmoInMagazine;
    AttackCooldown = .27f;
    MuzzleFlashRemaining = .065f;
    if (MuzzleFlash) MuzzleFlash->SetVisibility(true);

    if (USoundBase* Shot = LoadObject<USoundBase>(nullptr,
        TEXT("/Game/Audio/blackwood_pistol_shot.blackwood_pistol_shot")))
    {
        UGameplayStatics::PlaySound2D(this, Shot, .75f);
    }
    else
    {
        BWPlay2D(this, TEXT("/Game/Audio/blackwood_attack.blackwood_attack"), .8f, .65f);
    }

    // Hitscan: one line trace from the FPP camera; 2 damage versus a Watcher.
    if (ABWWatcher* Enemy = Cast<ABWWatcher>(TraceLook(4700.f)))
    {
        TWeakObjectPtr<ABWWatcher> SafeEnemy(Enemy);
        for (int32 i = 0; i < 2 && SafeEnemy.IsValid(); ++i)
            SafeEnemy->ReceiveMeleeHit();
        Notify(TEXT("Trafienie z pistoletu!"), .95f);
    }
    else if (AmmoInMagazine == 0)
    {
        Notify(TEXT("Magazynek pusty - nacisnij R."), 1.6f);
    }
}

void ABWCharacter::BuildCampfire()
{
    if (bDead) return;
    if (Wood < 5 || Stone < 3) { Notify(TEXT("Ognisko: potrzebujesz 5 drewna i 3 kamieni."),4.f); return; }
    const FVector Fwd = GetActorForwardVector();
    const FVector Place = GetActorLocation()+Fwd*230.f-FVector(0,0,85.f);
    FActorSpawnParameters Params;
    Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
    if (GetWorld()->SpawnActor<ABWCampfire>(ABWCampfire::StaticClass(),Place,FRotator::ZeroRotator,Params))
    {
        Wood -= 5; Stone -= 3;
        BWPlayAtLocation(this, Place, TEXT("/Game/Audio/blackwood_pickup.blackwood_pickup"), 0.85f, 0.8f);
        Notify(TEXT("Zbudowano ognisko. Tutaj jest bezpieczniej."),4.f);
    }
}

void ABWCharacter::Eat()
{
    if (bDead) return;
    if (Berries < 1) { Notify(TEXT("Nie masz jagod.")); return; }
    Berries--; Hunger = FMath::Min(100.f,Hunger+28.f);
    BWPlay2D(this, TEXT("/Game/Audio/blackwood_pickup.blackwood_pickup"), 0.45f, 1.2f);
    Notify(TEXT("Zjedzono jagody: +28 glodu."));
}
void ABWCharacter::Drink()
{
    if (bDead) return;
    if (Water < 1) { Notify(TEXT("Nie masz wody.")); return; }
    Water--; Thirst = FMath::Min(100.f,Thirst+40.f);
    BWPlay2D(this, TEXT("/Game/Audio/blackwood_pickup.blackwood_pickup"), 0.45f, 0.9f);
    Notify(TEXT("Wypito wode: +40 pragnienia."));
}

void ABWCharacter::Notify(const FString& Text, float Seconds)
{
    FeedbackMessage = Text;
    MessageDuration = Seconds;
}

void ABWCharacter::TakeSurvivalDamage(float Amount)
{
    if (bDead || Amount <= 0.f) return;
    Health = FMath::Max(0.f,Health-Amount);
    if (Amount >= 5.f)
    {
        BWPlay2D(this, TEXT("/Game/Audio/blackwood_damage.blackwood_damage"), 0.72f, 1.0f);
    }

    if (Health <= 0.f)
    {
        bDead = true;
        bSprinting = false;
        GetCharacterMovement()->DisableMovement();
        Flashlight->SetVisibility(false);
        Notify(TEXT("UMARLES - nacisnij R, aby powrocic."),999.f);
    }
    else if (Amount >= 5.f) Notify(TEXT("Cos cie zaatakowalo!"),2.f);
}

void ABWCharacter::Respawn()
{
    // R reloads the pistol while alive, and respawns when dead.
    if (!bDead) { ReloadPistol(); return; }
    Health = Hunger = Thirst = Stamina = Battery = 100.f;
    AmmoInMagazine = 12;
    ReserveAmmo = 36;
    ReloadRemaining = 0.f;
    MuzzleFlashRemaining = 0.f;
    if (MuzzleFlash) MuzzleFlash->SetVisibility(false);
    Wood = Stone = Berries = Water = 0;
    bDead = false;
    bFlashlightOn = false;
    Flashlight->SetVisibility(false);
    GetCharacterMovement()->SetMovementMode(MOVE_Walking);
    SetActorLocation(SafeRespawnLocation,false,nullptr,ETeleportType::TeleportPhysics);
    UpdateHeldTool();
    Notify(TEXT("Obudziles sie przy skraju lasu."),5.f);
}
