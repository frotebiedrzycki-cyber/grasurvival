#include "BWGameMode.h"
#include "BWCharacter.h"
#include "BWPlayerController.h"
#include "BWHUD.h"
#include "BWWorldDirector.h"
#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/PlayerStart.h"

ABWGameMode::ABWGameMode()
{
    DefaultPawnClass = ABWCharacter::StaticClass();
    PlayerControllerClass = ABWPlayerController::StaticClass();
    HUDClass = ABWHUD::StaticClass();
    bStartPlayersAsSpectators = false;
}

void ABWGameMode::BeginPlay()
{
    Super::BeginPlay();
    TArray<AActor*> ExistingDirectors;
    UGameplayStatics::GetAllActorsOfClass(this, ABWWorldDirector::StaticClass(), ExistingDirectors);
    if (GetWorld() && ExistingDirectors.Num() == 0)
    {
        GetWorld()->SpawnActor<ABWWorldDirector>(FVector::ZeroVector, FRotator::ZeroRotator);
    }
    UE_LOG(LogTemp, Display, TEXT("BLACKWOOD_BOOT: BWGameMode active; map=%s; pawn=%s; controller=%s"),
        GetWorld() ? *GetWorld()->GetMapName() : TEXT("NONE"),
        *GetNameSafe(DefaultPawnClass), *GetNameSafe(PlayerControllerClass));
}

void ABWGameMode::RestartPlayer(AController* NewPlayer)
{
    if (!NewPlayer || !GetWorld()) return;

    // Dedicated, override-free Entry map is the default; no demo-map GameMode can steal control.
    // For an optional custom level, probe its ground first, otherwise use a safe starting height.
    FVector SpawnLocation(0.f, 0.f, 235.f);
    FRotator SpawnRotation(0.f, 0.f, 0.f);
    if (AActor* Start = FindPlayerStart(NewPlayer))
    {
        SpawnLocation = Start->GetActorLocation() + FVector(0.f, 0.f, 120.f);
        SpawnRotation = Start->GetActorRotation();
    }
    else
    {
        FHitResult Ground;
        FCollisionQueryParams Query(SCENE_QUERY_STAT(BWSpawnGround), true);
        if (GetWorld()->LineTraceSingleByChannel(Ground, FVector(0,0,20000), FVector(0,0,-20000), ECC_Visibility, Query)
            && Ground.ImpactNormal.Z > 0.6f)
        {
            SpawnLocation = Ground.ImpactPoint + FVector(0.f,0.f,135.f);
        }
    }

    RestartPlayerAtTransform(NewPlayer, FTransform(SpawnRotation, SpawnLocation));
    APlayerController* PC = Cast<APlayerController>(NewPlayer);
    if (PC && !Cast<ABWCharacter>(PC->GetPawn()))
    {
        FActorSpawnParameters Params;
        Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
        ABWCharacter* Character = GetWorld()->SpawnActor<ABWCharacter>(ABWCharacter::StaticClass(), SpawnLocation, SpawnRotation, Params);
        if (Character) PC->Possess(Character);
    }

    if (PC)
    {
        UE_LOG(LogTemp, Display, TEXT("BLACKWOOD_BOOT: Possessed=%s"), *GetNameSafe(PC->GetPawn()));
    }
}
