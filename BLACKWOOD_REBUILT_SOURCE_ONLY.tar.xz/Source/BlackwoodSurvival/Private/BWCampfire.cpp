#include "BWCampfire.h"
#include "BWVisuals.h"
#include "Components/SceneComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/PointLightComponent.h"

ABWCampfire::ABWCampfire()
{
    PrimaryActorTick.bCanEverTick = true;
    Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root")); RootComponent = Root;
    Stones = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("StoneRing")); Stones->SetupAttachment(Root);
    Wood = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Logs")); Wood->SetupAttachment(Root);
    Flame = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Flame")); Flame->SetupAttachment(Root);
    Stones->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    Wood->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    Flame->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    FireLight = CreateDefaultSubobject<UPointLightComponent>(TEXT("WarmLight")); FireLight->SetupAttachment(Root);
    FireLight->SetRelativeLocation(FVector(0,0,110));
    FireLight->SetLightColor(FLinearColor(1,0.31f,0.08f));
    FireLight->SetIntensity(12000.f);
    FireLight->SetAttenuationRadius(900.f);
    FireLight->SetCastShadows(true);
}

void ABWCampfire::Tick(float DeltaSeconds)
{
    Super::Tick(DeltaSeconds);
    Clock += DeltaSeconds;
    const float Flicker = 1.0f + 0.10f * FMath::Sin(Clock * 14.f) + 0.06f * FMath::Sin(Clock * 29.f);
    FireLight->SetIntensity(12000.f * Flicker);
    Flame->SetRelativeScale3D(FVector(.48f,.48f,1.15f * Flicker));
}

void ABWCampfire::BeginPlay()
{
    Super::BeginPlay();
    Stones->SetStaticMesh(BWVisuals::Mesh(TEXT("Sphere")));
    Stones->SetRelativeLocation(FVector(0,0,12));
    Stones->SetRelativeScale3D(FVector(1.5f,1.3f,0.30f));
    BWVisuals::Tint(Stones, FLinearColor(0.18f,0.20f,0.22f));
    Wood->SetStaticMesh(BWVisuals::Mesh(TEXT("Cylinder")));
    Wood->SetRelativeLocation(FVector(0,0,30));
    Wood->SetRelativeRotation(FRotator(0,0,80));
    Wood->SetRelativeScale3D(FVector(.33f,.33f,1.25f));
    BWVisuals::Tint(Wood, FLinearColor(0.21f,0.105f,0.05f));
    Flame->SetStaticMesh(BWVisuals::Mesh(TEXT("Cone")));
    Flame->SetRelativeLocation(FVector(0,0,92));
    Flame->SetRelativeScale3D(FVector(.48f,.48f,1.15f));
    BWVisuals::Tint(Flame, FLinearColor(1.f,.24f,.025f), true);
}
