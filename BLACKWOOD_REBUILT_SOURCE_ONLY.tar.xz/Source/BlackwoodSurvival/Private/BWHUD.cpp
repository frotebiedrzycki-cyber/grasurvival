#include "BWHUD.h"
#include "BWCharacter.h"
#include "Engine/Canvas.h"
#include "Engine/Engine.h"
#include "GameFramework/PlayerController.h"

void ABWHUD::Bar(float X, float Y, float W, const FString& Label, float Amount, const FLinearColor& Color)
{
    DrawText(Label, FLinearColor(.68f,.78f,.84f), X, Y, GEngine->GetSmallFont(), .90f);
    DrawRect(FLinearColor(.06f,.075f,.086f,.92f), X+115.f, Y+4.f, W, 11.f);
    DrawRect(Color, X+115.f, Y+4.f, W*FMath::Clamp(Amount/100.f,0.f,1.f), 11.f);
    DrawText(FString::Printf(TEXT("%d"),FMath::RoundToInt(Amount)), FLinearColor(.92f,.94f,.95f), X+118.f+W, Y-1.f, GEngine->GetSmallFont(), .90f);
}

void ABWHUD::DrawHUD()
{
    Super::DrawHUD();
    if (!Canvas || !GEngine || !PlayerOwner) return;
    const ABWCharacter* Player = Cast<ABWCharacter>(PlayerOwner->GetPawn());
    if (!Player) return;

    const float ScreenW = Canvas->SizeX;
    const float ScreenH = Canvas->SizeY;
    const FLinearColor White(.9f,.94f,.95f);
    const FLinearColor Subtle(.57f,.67f,.72f);
    const FLinearColor Amber(.93f,.66f,.32f);

    // Dark cinematic frame.
    DrawRect(FLinearColor(.005f,.01f,.017f,.42f), 0, 0, ScreenW, 7.f);
    DrawRect(FLinearColor(.005f,.01f,.017f,.42f), 0, ScreenH-9.f, ScreenW, 9.f);
    if (Player->Health < 35.f)
    {
        const float RedAlpha = (35.f - Player->Health)/35.f * .23f;
        DrawRect(FLinearColor(.36f,.015f,.025f,RedAlpha), 0, 0, ScreenW, ScreenH);
    }

    // Compact survival card.
    DrawRect(FLinearColor(.015f,.03f,.04f,.87f), 18.f, 18.f, 330.f, 198.f);
    DrawRect(FLinearColor(.25f,.55f,.60f,.85f), 18.f, 18.f, 330.f, 2.f);
    DrawText(TEXT("BLACKWOOD  /  LOST SIGNAL"), White, 31.f, 30.f, GEngine->GetMediumFont(), .83f);
    Bar(30.f, 73.f, 135.f, TEXT("ZDROWIE"), Player->Health, FLinearColor(.91f,.23f,.26f));
    Bar(30.f, 101.f, 135.f, TEXT("GLOD"), Player->Hunger, FLinearColor(.90f,.63f,.33f));
    Bar(30.f, 129.f, 135.f, TEXT("WODA"), Player->Thirst, FLinearColor(.27f,.68f,.89f));
    Bar(30.f, 157.f, 135.f, TEXT("STAMINA"), Player->Stamina, FLinearColor(.42f,.83f,.58f));
    Bar(30.f, 185.f, 135.f, TEXT("BATERIA"), Player->Battery, FLinearColor(.85f,.81f,.43f));

    // Objective card in top-right, away from the hotbar.
    if (ScreenW > 950.f)
    {
        const float ObjX=ScreenW-418.f;
        DrawRect(FLinearColor(.013f,.022f,.032f,.83f),ObjX,18.f,401.f,77.f);
        DrawText(TEXT("CEL MISJI / SOS"),Amber,ObjX+14.f,29.f,GEngine->GetSmallFont(),1.10f);
        const FString Text = Player->HasRepairedRadio() ? TEXT("RADIO NAPRAWIONE  -  SOS WYSLANE") : TEXT("Znajdz radio: 8 drewna / 5 kamieni");
        DrawText(Text,White,ObjX+14.f,59.f,GEngine->GetSmallFont(),.96f);
    }

    if (!Player->IsDead() && !Player->IsInventoryOpen())
    {
        const float MidX=ScreenW*.5f, MidY=ScreenH*.5f;
        DrawRect(White, MidX-1.f, MidY-8.f, 2.f, 16.f);
        DrawRect(White, MidX-8.f, MidY-1.f, 16.f, 2.f);
        const FString Prompt=Player->GetInteractionPrompt();
        if (!Prompt.IsEmpty())
        {
            DrawRect(FLinearColor(.012f,.025f,.032f,.85f),MidX-200.f,MidY+31.f,400.f,36.f);
            DrawText(Prompt,White,MidX-188.f,MidY+42.f,GEngine->GetSmallFont(),.98f);
        }
    }

    // 10 inventory-linked hotbar slots; number 0 means slot index 9.
    const float SlotSize=70.f;
    const float SlotGap=5.f;
    const float BarWidth=10.f*SlotSize + 9.f*SlotGap;
    const float StartX=(ScreenW-BarWidth)*.5f;
    const float Y=ScreenH-96.f;
    DrawRect(FLinearColor(.005f,.013f,.018f,.72f),StartX-10.f,Y-26.f,BarWidth+20.f,103.f);

    DrawText(FString::Printf(TEXT("AKTYWNY: %s  |  LPM uzyj  |  E zbieraj"),
        *Player->GetHotbarItemName(Player->GetSelectedHotbarSlot())),White,StartX,Y-21.f,GEngine->GetSmallFont(),.96f);
    if (Player->GetSelectedHotbarSlot() == 3)
    {
        const FString PistolInfo = Player->IsPistolReloading() ? TEXT("PRZELADOWYWANIE...") :
            FString::Printf(TEXT("9MM  %d / %d   [R]"),Player->GetAmmoInMagazine(),Player->GetReserveAmmo());
        DrawText(PistolInfo,Amber,StartX+510.f,Y-21.f,GEngine->GetSmallFont(),.91f);
    }

    for (int32 Slot=0; Slot<10; ++Slot)
    {
        const float X=StartX + Slot*(SlotSize+SlotGap);
        const bool bSelected=Player->GetSelectedHotbarSlot()==Slot;
        const bool bAvailable=Player->HasHotbarItem(Slot);
        DrawRect(bSelected ? FLinearColor(.16f,.26f,.31f,.94f) : FLinearColor(.022f,.038f,.049f,.92f),
                 X,Y,SlotSize,SlotSize);
        if (bSelected)
        {
            DrawRect(FLinearColor(.95f,.72f,.38f),X,Y,SlotSize,3.f);
            DrawRect(FLinearColor(.95f,.72f,.38f),X,Y+SlotSize-3.f,SlotSize,3.f);
        }
        const FString KeyLabel=Slot==9?TEXT("0"):FString::FromInt(Slot+1);
        DrawText(KeyLabel,bSelected?Amber:Subtle,X+6.f,Y+5.f,GEngine->GetSmallFont(),.98f);
        const FString ItemName=Player->GetHotbarItemName(Slot);
        const float Scale=ItemName.Len()>=7 ? .66f : .76f;
        DrawText(ItemName,bAvailable?White:Subtle,X+5.f,Y+34.f,GEngine->GetSmallFont(),Scale);
        if (Slot==6 || Slot==7 || Slot==8)
        {
            DrawText(FString::FromInt(Player->GetHotbarItemCount(Slot)),bAvailable?Amber:Subtle,
                     X+51.f,Y+6.f,GEngine->GetSmallFont(),.87f);
        }
        // Category color streak.
        const FLinearColor Category = Slot<=4 ? FLinearColor(.68f,.70f,.75f) :
            (Slot==5 ? FLinearColor(.86f,.83f,.41f) : FLinearColor(.35f,.69f,.55f));
        DrawRect(Category, X+6.f, Y+26.f, SlotSize-12.f, 3.f);
    }

    if (!Player->GetMessage().IsEmpty())
    {
        const float X=ScreenW*.5f-272.f;
        DrawRect(FLinearColor(.025f,.028f,.032f,.88f),X,20.f,544.f,42.f);
        DrawText(Player->GetMessage(),Amber,X+10.f,31.f,GEngine->GetSmallFont(),1.04f);
    }

    if (Player->IsInventoryOpen() && !Player->IsDead())
    {
        const float PWidth=650.f;
        const float PX=(ScreenW-PWidth)*.5f;
        const float PY=FMath::Max(70.f,(ScreenH-510.f)*.5f);
        DrawRect(FLinearColor(.014f,.027f,.038f,.97f),PX,PY,PWidth,490.f);
        DrawRect(Amber,PX,PY,PWidth,3.f);
        DrawText(TEXT("PLECAK  /  WYPOSAZENIE"),White,PX+25.f,PY+18.f,GEngine->GetMediumFont(),1.18f);
        DrawText(TEXT("NARZEDZIA I BRONIE  |  LPM - uzyj aktywnego slotu"),Subtle,PX+25.f,PY+60.f,GEngine->GetSmallFont(),.97f);
        DrawText(FString::Printf(TEXT("PISTOLET 9MM: %d / %d  |  R przeladuj"),
            Player->GetAmmoInMagazine(), Player->GetReserveAmmo()),Amber,PX+25.f,PY+82.f,GEngine->GetSmallFont(),.93f);
        for (int32 Slot=0;Slot<10;++Slot)
        {
            const int32 Col=Slot/5;
            const int32 Row=Slot%5;
            const float X=PX+25.f+Col*310.f;
            const float RowY=PY+101.f+Row*45.f;
            const bool bActive=Player->GetSelectedHotbarSlot()==Slot;
            DrawRect(bActive?FLinearColor(.16f,.29f,.30f,.95f):FLinearColor(.055f,.09f,.105f,.75f), X, RowY, 290.f, 39.f);
            DrawText(FString::Printf(TEXT("[%d] %s"), Slot==9?0:Slot+1, *Player->GetHotbarItemName(Slot)),
                     bActive?Amber:White,X+9.f,RowY+11.f,GEngine->GetSmallFont(),1.01f);
            if (Slot==6 || Slot==7 || Slot==8)
                DrawText(FString::FromInt(Player->GetHotbarItemCount(Slot)),Amber,X+263.f,RowY+11.f,GEngine->GetSmallFont(),1.03f);
        }

        DrawText(TEXT("ZASOBY"),Amber,PX+25.f,PY+341.f,GEngine->GetSmallFont(),1.08f);
        DrawRect(FLinearColor(.045f,.075f,.082f,.89f),PX+25.f,PY+367.f,600.f,58.f);
        DrawText(FString::Printf(TEXT("Drewno  %d       Kamien  %d       Jagody  %d       Woda  %d"),
            Player->Wood,Player->Stone,Player->Berries,Player->Water),White,PX+40.f,PY+386.f,GEngine->GetSmallFont(),1.09f);
        DrawText(TEXT("1-0 wybierz slot   |   E interakcja   |   F latarka   |   TAB zamknij"),Subtle,
                 PX+25.f,PY+451.f,GEngine->GetSmallFont(),.92f);
    }

    if (Player->IsDead())
    {
        DrawRect(FLinearColor(.08f,.005f,.014f,.92f),0,0,ScreenW,ScreenH);
        DrawText(TEXT("UMARLES"),FLinearColor(1.f,.18f,.18f),ScreenW*.5f-170.f,ScreenH*.5f-70.f,GEngine->GetLargeFont(),2.f);
        DrawText(TEXT("R - odrodzenie"),White,ScreenW*.5f-95.f,ScreenH*.5f+30.f,GEngine->GetMediumFont(),1.1f);
    }
}
