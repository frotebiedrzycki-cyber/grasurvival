#include "BWPlayerController.h"
#include "BWMainMenuWidget.h"
#include "BWCharacter.h"
#include "Kismet/GameplayStatics.h"
#include "Blueprint/UserWidget.h"
#include "GameFramework/GameModeBase.h"
#include "Engine/World.h"
#include "Components/InputComponent.h"

void ABWPlayerController::BeginPlay()
{
    Super::BeginPlay();
    if (IsLocalController()) ShowMainMenu();
}

void ABWPlayerController::SetupInputComponent()
{
    Super::SetupInputComponent();
    if (InputComponent)
    {
        InputComponent->BindAction(TEXT("PauseMenu"), IE_Pressed, this, &ABWPlayerController::ToggleMenu);
    }
}

void ABWPlayerController::ShowMainMenu()
{
    if (!IsLocalController()) return;
    if (!MenuWidget)
    {
        MenuWidget = CreateWidget<UBWMainMenuWidget>(this, UBWMainMenuWidget::StaticClass());
    }
    if (!MenuWidget) { UE_LOG(LogTemp, Error, TEXT("BLACKWOOD_BOOT: menu widget failed")); return; }
    if (!MenuWidget->IsInViewport()) MenuWidget->AddToViewport(999);

    bMenuOpen = true;
    bShowMouseCursor = true;
    FInputModeGameAndUI Mode;
    Mode.SetHideCursorDuringCapture(false);
    SetInputMode(Mode);
    SetIgnoreMoveInput(true);
    SetIgnoreLookInput(true);
    UE_LOG(LogTemp, Display, TEXT("BLACKWOOD_BOOT: menu visible"));
}

void ABWPlayerController::StartGame()
{
    if (MenuWidget && MenuWidget->IsInViewport()) MenuWidget->RemoveFromParent();
    bMenuOpen = false;
    bShowMouseCursor = false;
    SetIgnoreMoveInput(false);
    SetIgnoreLookInput(false);
    FInputModeGameOnly Mode;
    SetInputMode(Mode);

    if (!Cast<ABWCharacter>(GetPawn()))
    {
        if (AGameModeBase* GameMode = UGameplayStatics::GetGameMode(this))
        {
            GameMode->RestartPlayer(this);
        }
    }
    if (ABWCharacter* BW = Cast<ABWCharacter>(GetPawn()))
    {
        SetViewTarget(BW);
        UE_LOG(LogTemp, Display, TEXT("BLACKWOOD_BOOT: game started; controlled=%s"), *GetNameSafe(BW));
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("BLACKWOOD_BOOT: no ABWCharacter after StartGame"));
        ShowMainMenu();
    }
}

void ABWPlayerController::ToggleMenu()
{
    if (bMenuOpen) StartGame(); else ShowMainMenu();
}

void ABWPlayerController::QuitGame()
{
    ConsoleCommand(TEXT("quit"));
}
