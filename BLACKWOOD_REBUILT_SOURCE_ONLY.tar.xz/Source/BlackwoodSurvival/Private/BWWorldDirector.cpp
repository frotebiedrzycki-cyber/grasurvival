#include "BWWorldDirector.h"
#include "BWVisuals.h"
#include "BWResourceNode.h"
#include "BWPickup.h"
#include "BWWatcher.h"
#include "BWRadio.h"
#include "Components/SceneComponent.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/PointLightComponent.h"
#include "Components/DirectionalLightComponent.h"
#include "Components/ExponentialHeightFogComponent.h"
#include "Engine/DirectionalLight.h"
#include "Engine/ExponentialHeightFog.h"
#include "Engine/PointLight.h"
#include "Engine/StaticMeshActor.h"
#include "Engine/World.h"
#include "Engine/StaticMesh.h"
#include "Materials/MaterialInterface.h"
#include "Sound/SoundBase.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/SkyLight.h"
#include "Engine/EngineTypes.h"

ABWWorldDirector::ABWWorldDirector()
{
    PrimaryActorTick.bCanEverTick = false;
    Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root")); RootComponent = Root;
    ForestTrunks = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("ForestTrunks"));
    ForestTrunks->SetupAttachment(Root);
    ForestCanopies = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("ForestCanopies"));
    ForestCanopies->SetupAttachment(Root);
    ForestRocks = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("ForestRocks"));
    ForestRocks->SetupAttachment(Root);
    ForestStumps = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("ForestDeadwood"));
    ForestStumps->SetupAttachment(Root);
    ForestBroadleaf = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("ForestBroadleaf"));
    ForestBroadleaf->SetupAttachment(Root);
    ForestBoulders = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("ForestBoulders"));
    ForestBoulders->SetupAttachment(Root);
    ForestBushes = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("ForestBushes"));
    ForestBushes->SetupAttachment(Root);
    ForestGrass = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("ForestGrass"));
    ForestGrass->SetupAttachment(Root);
    ForestFlowers = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("ForestFlowers"));
    ForestFlowers->SetupAttachment(Root);
    ForestBroadleaf->SetCollisionProfileName(TEXT("BlockAll"));
    ForestBoulders->SetCollisionProfileName(TEXT("BlockAll"));
    ForestBushes->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    ForestGrass->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    ForestFlowers->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    ForestTrunks->SetCollisionProfileName(TEXT("BlockAll"));
    ForestCanopies->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    ForestRocks->SetCollisionProfileName(TEXT("BlockAll"));
    ForestStumps->SetCollisionProfileName(TEXT("BlockAll"));
}

void ABWWorldDirector::BeginPlay()
{
    Super::BeginPlay();
    GenerateScene();
    if (USoundBase* Wind = LoadObject<USoundBase>(nullptr,
        TEXT("/Game/Audio/blackwood_night_ambience.blackwood_night_ambience")))
    {
        UGameplayStatics::PlaySound2D(this,Wind,0.70f);
    }
}

void ABWWorldDirector::SpawnBox(const FVector& Position, const FVector& Size,
                               const FLinearColor& Color, const FRotator& Rotation)
{
    AStaticMeshActor* Box = GetWorld()->SpawnActor<AStaticMeshActor>(Position,Rotation);
    if (!Box) return;
    UStaticMeshComponent* Comp = Box->GetStaticMeshComponent();
    Comp->SetMobility(EComponentMobility::Movable);
    Comp->SetStaticMesh(BWVisuals::Mesh(TEXT("Cube")));
    Comp->SetWorldScale3D(Size/100.f);
    Comp->SetCollisionProfileName(TEXT("BlockAll"));
    BWVisuals::Tint(Comp,Color);
    // Large floor uses the optional textured ground material generated in the editor.
    if (Size.X > 15000.f && Size.Y > 15000.f && Size.Z < 200.f)
    {
        if (UMaterialInterface* Ground = LoadObject<UMaterialInterface>(nullptr,
            TEXT("/Game/Materials/M_BWGround.M_BWGround")))
        {
            Comp->SetMaterial(0, Ground);
        }
    }
}

void ABWWorldDirector::GenerateScene()
{
    // v0.4: Keep the complete authored StyleHex landscape/materials/foliage intact.
    // Only add interaction, radio and creatures on the demo level. Never cover its
    // ground with the old huge gray cube (the main visual problem in v0.3).
    const FString CurrentMap = GetWorld() ? GetWorld()->GetMapName() : FString();
    if (CurrentMap.Contains(TEXT("World_Demo")) || CurrentMap.Contains(TEXT("Preview_Scene")))
    {
        // Dim the daylight designed for showcasing assets, creating a horror night.
        TArray<AActor*> Directionals;
        UGameplayStatics::GetAllActorsOfClass(this, ADirectionalLight::StaticClass(), Directionals);
        for (AActor* A : Directionals)
        {
            if (ADirectionalLight* Light = Cast<ADirectionalLight>(A))
            {
                Light->GetLightComponent()->SetIntensity(0.30f);
                Light->GetLightComponent()->SetLightColor(FLinearColor(.37f,.47f,.72f));
            }
        }
        TArray<AActor*> Skies;
        UGameplayStatics::GetAllActorsOfClass(this, ASkyLight::StaticClass(), Skies);
        for (AActor* A : Skies)
        {
            if (ASkyLight* Sky = Cast<ASkyLight>(A))
                Sky->GetLightComponent()->SetIntensity(0.22f);
        }
        TArray<AActor*> Fogs;
        UGameplayStatics::GetAllActorsOfClass(this, AExponentialHeightFog::StaticClass(), Fogs);
        if (Fogs.IsEmpty())
        {
            if (AExponentialHeightFog* NewFog = GetWorld()->SpawnActor<AExponentialHeightFog>())
                Fogs.Add(NewFog);
        }
        for (AActor* A : Fogs)
        {
            if (AExponentialHeightFog* Fog = Cast<AExponentialHeightFog>(A))
            {
                UExponentialHeightFogComponent* C = Fog->GetComponent();
                C->SetFogDensity(0.025f);
                C->SetFogHeightFalloff(.13f);
                C->SetFogInscatteringColor(FLinearColor(.025f,.042f,.067f));
                C->SetVolumetricFog(true);
            }
        }

        const auto FindFloor = [this](const FVector& XY) -> FVector
        {
            FHitResult Hit;
            const FVector Start(XY.X, XY.Y, 100000.f);
            const FVector End(XY.X, XY.Y, -100000.f);
            if (GetWorld()->LineTraceSingleByChannel(Hit, Start, End, ECC_WorldStatic))
                return Hit.ImpactPoint + FVector(0.f,0.f,18.f);
            return FVector(XY.X,XY.Y,10.f);
        };
        FRandomStream Rng(42034);
        for (int32 I = 0; I < 45; ++I)
        {
            FVector XY(Rng.FRandRange(-2400.f,2400.f), Rng.FRandRange(-2400.f,2400.f), 0.f);
            if (XY.Size2D() < 450.f) XY.X += 620.f;
            const FVector Pos = FindFloor(XY);
            ABWResourceNode* Node = GetWorld()->SpawnActor<ABWResourceNode>(Pos, FRotator(0,Rng.FRandRange(0.f,360.f),0));
            if (Node) Node->Configure(I%2==0 ? EBWResourceType::Wood : EBWResourceType::Stone, I%2==0 ? 4 : 3);
        }
        for (int32 I = 0; I < 22; ++I)
        {
            FVector XY(Rng.FRandRange(-1900.f,1900.f), Rng.FRandRange(-1900.f,1900.f), 0.f);
            if (XY.Size2D() < 320.f) XY.Y += 500.f;
            ABWPickup* Pickup = GetWorld()->SpawnActor<ABWPickup>(FindFloor(XY), FRotator::ZeroRotator);
            if (Pickup) Pickup->Configure(I%3 == 0 ? EBWPickupType::Water : EBWPickupType::Berries);
        }
        const FVector RadioPos = FindFloor(FVector(1250.f,480.f,0.f));
        GetWorld()->SpawnActor<ABWRadio>(RadioPos, FRotator(0,180,0));
        for (const FVector XY : { FVector(1400.f,-1500.f,0), FVector(-1700.f,1300.f,0), FVector(2200.f,1600.f,0) })
            GetWorld()->SpawnActor<ABWWatcher>(FindFloor(XY) + FVector(0,0,155.f), FRotator::ZeroRotator);

        UE_LOG(LogTemp, Log, TEXT("BLACKWOOD v0.4: full asset World_Demo loaded, prototype floor skipped."));
        return;
    }

    // Ground, berms and perimeter.
    SpawnBox(FVector(0,0,-72),FVector(16800,16800,120),FLinearColor(.04f,.055f,.048f));
    SpawnBox(FVector(-8400,0,360),FVector(180,16900,800),FLinearColor(.07f,.085f,.095f));
    SpawnBox(FVector(8400,0,360),FVector(180,16900,800),FLinearColor(.07f,.085f,.095f));
    SpawnBox(FVector(0,-8400,360),FVector(16900,180,800),FLinearColor(.07f,.085f,.095f));
    SpawnBox(FVector(0,8400,360),FVector(16900,180,800),FLinearColor(.07f,.085f,.095f));

    FRandomStream Rng(48201);
    for (int32 i=0; i<26; ++i)
    {
        const FVector P(Rng.FRandRange(-7200, 7200), Rng.FRandRange(-7200, 7200), Rng.FRandRange(-15.f, 10.f));
        const FVector S(Rng.FRandRange(220, 640), Rng.FRandRange(220, 640), Rng.FRandRange(80, 180));
        SpawnBox(P, S, FLinearColor(.05f,.065f,.055f));
    }

    if (ADirectionalLight* Moon = GetWorld()->SpawnActor<ADirectionalLight>(FVector(0,0,6500),FRotator(-30,-120,0)))
    {
        Moon->GetLightComponent()->SetIntensity(0.48f);
        Moon->GetLightComponent()->SetLightColor(FLinearColor(.28f,.39f,.72f));
        Moon->GetLightComponent()->SetCastShadows(true);
    }
    if (AExponentialHeightFog* Fog = GetWorld()->SpawnActor<AExponentialHeightFog>())
    {
        auto* FogComponent = Fog->GetComponent();
        FogComponent->SetFogDensity(.036f);
        FogComponent->SetFogHeightFalloff(.14f);
        FogComponent->SetFogInscatteringColor(FLinearColor(.02f,.045f,.065f));
        FogComponent->SetVolumetricFog(true);
    }

    // The imported Fab assets carry their own materials and textures. Do not Tint them:
    // Tint would override the authored materials with the gray prototype material.
    const auto LoadForestMesh = [](const FString& Folder, const FString& Name) -> UStaticMesh*
    {
        const FString AssetPath = FString::Printf(
            TEXT("/Game/StyleHex_Studio/Free_Packs/FREE_Stylized_Forest_Sample/Meshes/%s/%s.%s"),
            *Folder, *Name, *Name);
        return LoadObject<UStaticMesh>(nullptr, *AssetPath);
    };

    UStaticMesh* BirchA = LoadForestMesh(TEXT("Trees"), TEXT("SM_Tree_Birch_1"));
    UStaticMesh* BirchB = LoadForestMesh(TEXT("Trees"), TEXT("SM_Tree_Birch_2"));
    UStaticMesh* BroadleafA = LoadForestMesh(TEXT("Trees"), TEXT("SM_Tree_Broadleaf_1"));
    UStaticMesh* BroadleafB = LoadForestMesh(TEXT("Trees"), TEXT("SM_Tree_Broadleaf_2"));
    const bool bImportedForestReady = BirchA && BirchB && BroadleafA && BroadleafB;

    if (bImportedForestReady)
    {
        ForestTrunks->SetStaticMesh(BirchA);
        ForestCanopies->SetStaticMesh(BirchB);
        ForestStumps->SetStaticMesh(BroadleafA);
        ForestBroadleaf->SetStaticMesh(BroadleafB);
        ForestCanopies->SetCollisionProfileName(TEXT("BlockAll"));
        ForestStumps->SetCollisionProfileName(TEXT("BlockAll"));

        for (int32 i=0; i<395; ++i)
        {
            FVector P(Rng.FRandRange(-7800,7800),Rng.FRandRange(-7800,7800),0.f);
            if (P.Size2D() < 750.f || FVector::Dist2D(P,FVector(2650,650,0)) < 1100.f)
                continue;
            UInstancedStaticMeshComponent* TreeComponent = nullptr;
            switch (Rng.RandRange(0,3))
            {
                case 0: TreeComponent = ForestTrunks; break;
                case 1: TreeComponent = ForestCanopies; break;
                case 2: TreeComponent = ForestStumps; break;
                default: TreeComponent = ForestBroadleaf; break;
            }
            const float Scale = Rng.FRandRange(.82f,1.32f);
            TreeComponent->AddInstance(FTransform(FRotator(0,Rng.FRandRange(0,360),0),P,FVector(Scale)));
        }

        if (UStaticMesh* Mesh = LoadForestMesh(TEXT("Foliage"),TEXT("SM_Fol_Bush_1")))
        {
            ForestBushes->SetStaticMesh(Mesh);
            for (int32 i=0; i<190; ++i)
            {
                FVector P(Rng.FRandRange(-7600,7600),Rng.FRandRange(-7600,7600),0);
                if (P.Size2D() < 300.f) continue;
                ForestBushes->AddInstance(FTransform(FRotator(0,Rng.FRandRange(0,360),0),P,FVector(Rng.FRandRange(.6f,1.35f))));
            }
        }
        if (UStaticMesh* Mesh = LoadForestMesh(TEXT("Foliage"),TEXT("SM_Fol_Grass_Clump_1")))
        {
            ForestGrass->SetStaticMesh(Mesh);
            for (int32 i=0; i<650; ++i)
            {
                FVector P(Rng.FRandRange(-7900,7900),Rng.FRandRange(-7900,7900),0);
                ForestGrass->AddInstance(FTransform(FRotator(0,Rng.FRandRange(0,360),0),P,FVector(Rng.FRandRange(.72f,1.35f))));
            }
        }
        if (UStaticMesh* Mesh = LoadForestMesh(TEXT("Foliage"),TEXT("SM_Fol_Flower_Clump_1")))
        {
            ForestFlowers->SetStaticMesh(Mesh);
            for (int32 i=0; i<115; ++i)
            {
                FVector P(Rng.FRandRange(-7800,7800),Rng.FRandRange(-7800,7800),0);
                ForestFlowers->AddInstance(FTransform(FRotator(0,Rng.FRandRange(0,360),0),P,FVector(Rng.FRandRange(.7f,1.1f))));
            }
        }
    }
    else
    {
        // Original v0.2 forest is still usable when imported meshes are unavailable.
        ForestTrunks->SetStaticMesh(BWVisuals::Mesh(TEXT("Cylinder")));
        ForestCanopies->SetStaticMesh(BWVisuals::Mesh(TEXT("Cone")));
        ForestStumps->SetStaticMesh(BWVisuals::Mesh(TEXT("Cylinder")));
        BWVisuals::Tint(ForestTrunks,FLinearColor(.12f,.08f,.06f));
        BWVisuals::Tint(ForestCanopies,FLinearColor(.015f,.08f,.065f));
        BWVisuals::Tint(ForestStumps,FLinearColor(.10f,.07f,.05f));
        for (int32 i=0; i<380; ++i)
        {
            const FVector P(Rng.FRandRange(-7800,7800),Rng.FRandRange(-7800,7800),0);
            if (P.Size2D() < 820.f || FVector::Dist2D(P,FVector(2650,650,0)) < 1100.f) continue;
            const float Height = Rng.FRandRange(360,760);
            const float Width = Rng.FRandRange(.72f,1.65f);
            ForestTrunks->AddInstance(FTransform(FRotator(0,Rng.FRandRange(0,360),0),
                P+FVector(0,0,Height*.5f-12), FVector(.48f*Width,.48f*Width,Height/100.f)));
            for (int32 L=0;L<3;++L)
            {
                const float ScaleXY = 2.7f*Width - L*.36f;
                ForestCanopies->AddInstance(FTransform(FRotator(0,Rng.FRandRange(0,360),0),
                    P+FVector(0,0,Height*.56f+L*95.f),FVector(ScaleXY,ScaleXY,2.25f)));
            }
        }
        for (int32 i=0;i<80;i++)
        {
            const FVector P(Rng.FRandRange(-7600,7600),Rng.FRandRange(-7600,7600),0);
            ForestStumps->AddInstance(FTransform(FRotator::ZeroRotator,P+FVector(0,0,18),FVector(.26f,.26f,.35f)));
        }
    }

    // Rocks: keep imported stone materials and sculpted geometry where available.
    if (UStaticMesh* Stone = LoadForestMesh(TEXT("Stones"),TEXT("SM_Stone_1")))
    {
        ForestRocks->SetStaticMesh(Stone);
    }
    else
    {
        ForestRocks->SetStaticMesh(BWVisuals::Mesh(TEXT("Sphere")));
        BWVisuals::Tint(ForestRocks,FLinearColor(.13f,.16f,.18f));
    }
    ForestBoulders->SetStaticMesh(LoadForestMesh(TEXT("Stones"),TEXT("SM_Stone_Boulder_1")));
    for (int32 i=0;i<115;i++)
    {
        const FVector P(Rng.FRandRange(-7700,7700),Rng.FRandRange(-7700,7700),0);
        if (P.Size2D() < 460.f || FVector::Dist2D(P,FVector(2650,650,0)) < 700.f) continue;
        const float W=Rng.FRandRange(.55f,1.55f);
        if (ForestBoulders->GetStaticMesh() && i%5==0)
        {
            ForestBoulders->AddInstance(FTransform(FRotator(0,Rng.FRandRange(0,180),0),P,FVector(W)));
        }
        else if (bImportedForestReady)
        {
            ForestRocks->AddInstance(FTransform(FRotator(0,Rng.FRandRange(0,180),0),P,FVector(W)));
        }
        else
        {
            ForestRocks->AddInstance(FTransform(FRotator(0,Rng.FRandRange(0,180),0),
                P+FVector(0,0,18.f*W),FVector(W*1.2f,W*.88f,W*.42f)));
        }
    }

    // Resource nodes and consumables.
    for (int32 i=0;i<74;i++)
    {
        FVector Pos;
        if (i < 30)
            Pos = FVector(Rng.FRandRange(-1900,1900),Rng.FRandRange(-1900,1900),0);
        else
            Pos = FVector(Rng.FRandRange(-7200,7200),Rng.FRandRange(-7200,7200),0);
        if (Pos.Size2D() < 350.f) Pos += FVector(480,380,0);
        ABWResourceNode* Node = GetWorld()->SpawnActor<ABWResourceNode>(Pos,FRotator(0,Rng.FRandRange(0,360),0));
        if (Node) Node->Configure(i % 2 == 0 ? EBWResourceType::Wood : EBWResourceType::Stone, i%2==0 ? 4 : 3);
    }
    for (int32 i=0;i<36;i++)
    {
        FVector Pos(i<18 ? Rng.FRandRange(-2200,2200):Rng.FRandRange(-6900,6900),
                    i<18 ? Rng.FRandRange(-2200,2200):Rng.FRandRange(-6900,6900),0);
        if (Pos.Size2D() < 330.f) Pos += FVector(-510,470,0);
        ABWPickup* Pickup = GetWorld()->SpawnActor<ABWPickup>(Pos,FRotator::ZeroRotator);
        if (Pickup) Pickup->Configure(i%3==0 ? EBWPickupType::Water : EBWPickupType::Berries);
    }

    // Footpath toward the station.
    for (int32 i=0; i<8; ++i)
    {
        const float Alpha = i / 7.0f;
        const FVector P = FMath::Lerp(FVector(300,80,8), FVector(2200,540,8), Alpha);
        SpawnBox(P, FVector(190,120,18), FLinearColor(.12f,.11f,.10f), FRotator(0,12,0));
    }

    // Grave markers near the start.
    for (int32 i=0; i<9; ++i)
    {
        const FVector Base(-1200 + i*140.f, 1200 + (i%3)*120.f, 10.f);
        SpawnBox(Base + FVector(0,0,78), FVector(36,12,140), FLinearColor(.18f,.19f,.20f));
        SpawnBox(Base + FVector(0,0,132), FVector(64,16,28), FLinearColor(.18f,.19f,.20f));
    }

    // Abandoned relay shack + details.
    SpawnBox(FVector(2600,650,5),FVector(1200,920,30),FLinearColor(.11f,.10f,.09f));
    SpawnBox(FVector(3210,650,190),FVector(50,930,350),FLinearColor(.16f,.14f,.12f));
    SpawnBox(FVector(2600,1130,190),FVector(1200,40,350),FLinearColor(.16f,.14f,.12f));
    SpawnBox(FVector(2600,170,190),FVector(1200,40,350),FLinearColor(.16f,.14f,.12f));
    SpawnBox(FVector(1990,350,190),FVector(50,240,350),FLinearColor(.16f,.14f,.12f));
    SpawnBox(FVector(1990,950,190),FVector(50,250,350),FLinearColor(.16f,.14f,.12f));
    SpawnBox(FVector(2600,650,405),FVector(1290,1020,40),FLinearColor(.08f,.08f,.09f));
    SpawnBox(FVector(2600,650,455),FVector(900,760,34),FLinearColor(.065f,.07f,.075f));
    SpawnBox(FVector(2380,650,105),FVector(170,160,180),FLinearColor(.24f,.22f,.17f));
    SpawnBox(FVector(2980,350,85),FVector(110,90,135),FLinearColor(.24f,.22f,.17f));
    SpawnBox(FVector(2860,940,85),FVector(110,90,135),FLinearColor(.20f,.18f,.15f));
    SpawnBox(FVector(2210,650,18),FVector(260,180,24),FLinearColor(.16f,.14f,.12f)); // porch slab
    SpawnBox(FVector(1880,650,220),FVector(30,30,480),FLinearColor(.22f,.24f,.26f)); // antenna mast
    SpawnBox(FVector(1880,650,470),FVector(90,20,20),FLinearColor(.22f,.24f,.26f));

    GetWorld()->SpawnActor<ABWRadio>(FVector(2740,670,25),FRotator(0,180,0));
    if (APointLight* StationLight=GetWorld()->SpawnActor<APointLight>(FVector(2580,640,300),FRotator::ZeroRotator))
    {
        StationLight->GetLightComponent()->SetIntensity(4600);
        StationLight->PointLightComponent->SetAttenuationRadius(650.f);
        StationLight->GetLightComponent()->SetLightColor(FLinearColor(.60f,.15f,.07f));
    }
    if (APointLight* WindowLight=GetWorld()->SpawnActor<APointLight>(FVector(2240,1100,210),FRotator::ZeroRotator))
    {
        WindowLight->GetLightComponent()->SetIntensity(2500);
        WindowLight->PointLightComponent->SetAttenuationRadius(420.f);
        WindowLight->GetLightComponent()->SetLightColor(FLinearColor(.22f,.62f,.95f));
    }
    if (APointLight* MastLight=GetWorld()->SpawnActor<APointLight>(FVector(1880,650,560),FRotator::ZeroRotator))
    {
        MastLight->GetLightComponent()->SetIntensity(5500);
        MastLight->PointLightComponent->SetAttenuationRadius(320.f);
        MastLight->GetLightComponent()->SetLightColor(FLinearColor(.95f,.05f,.05f));
    }

    // Small campsite away from spawn.
    SpawnBox(FVector(-1750,-1200,8), FVector(420,320,18), FLinearColor(.12f,.09f,.07f));
    SpawnBox(FVector(-1600,-1060,62), FVector(80,60,85), FLinearColor(.22f,.18f,.12f));
    SpawnBox(FVector(-1800,-980,54), FVector(140,28,46), FLinearColor(.18f,.18f,.18f));
    if (APointLight* CampLantern=GetWorld()->SpawnActor<APointLight>(FVector(-1600,-1060,160),FRotator::ZeroRotator))
    {
        CampLantern->GetLightComponent()->SetIntensity(2800);
        CampLantern->PointLightComponent->SetAttenuationRadius(460.f);
        CampLantern->GetLightComponent()->SetLightColor(FLinearColor(1.f,.48f,.16f));
    }

    GetWorld()->SpawnActor<ABWWatcher>(FVector(1550,-1650,170),FRotator::ZeroRotator);
    GetWorld()->SpawnActor<ABWWatcher>(FVector(-2050,1700,170),FRotator::ZeroRotator);
    GetWorld()->SpawnActor<ABWWatcher>(FVector(3950,1100,170),FRotator::ZeroRotator);
    GetWorld()->SpawnActor<ABWWatcher>(FVector(-3600,-2450,170),FRotator::ZeroRotator);
}
