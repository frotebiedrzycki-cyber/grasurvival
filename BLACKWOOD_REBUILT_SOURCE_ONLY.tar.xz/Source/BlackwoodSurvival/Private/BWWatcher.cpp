#include "BWWatcher.h"
#include "BWCharacter.h"
#include "BWCampfire.h"
#include "BWVisuals.h"
#include "Components/SphereComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/SkeletalMesh.h"
#include "Animation/AnimSequence.h"
#include "Components/PointLightComponent.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"

ABWWatcher::ABWWatcher()
{
    PrimaryActorTick.bCanEverTick = true;
    Collision = CreateDefaultSubobject<USphereComponent>(TEXT("TraceTarget"));
    RootComponent = Collision;
    Collision->InitSphereRadius(62.f);
    Collision->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
    Collision->SetCollisionResponseToAllChannels(ECR_Ignore);
    Collision->SetCollisionResponseToChannel(ECC_Visibility, ECR_Block);
    Body = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ShadowBody")); Body->SetupAttachment(Collision);
    EyeLeft = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("LeftEye")); EyeLeft->SetupAttachment(Collision);
    EyeRight = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("RightEye")); EyeRight->SetupAttachment(Collision);
    Body->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    EyeLeft->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    EyeRight->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    Glow = CreateDefaultSubobject<UPointLightComponent>(TEXT("ColdGlow")); Glow->SetupAttachment(Collision);
    Glow->SetIntensity(1800.f);
    Glow->SetAttenuationRadius(400.f);
    Glow->SetLightColor(FLinearColor(.7f,.035f,.07f));
    DetailedBody = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("WhisperMesh"));
    DetailedBody->SetupAttachment(Collision);
    DetailedBody->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    DetailedBody->SetVisibility(false);
}

void ABWWatcher::BeginPlay()
{
    Super::BeginPlay();
    Anchor = GetActorLocation();
    Body->SetStaticMesh(BWVisuals::Mesh(TEXT("Sphere")));
    Body->SetRelativeScale3D(FVector(.95f,.55f,2.0f));
    BWVisuals::Tint(Body, FLinearColor(.015f,.02f,.035f));
    EyeLeft->SetStaticMesh(BWVisuals::Mesh(TEXT("Sphere")));
    EyeLeft->SetRelativeScale3D(FVector(.11f,.12f,.11f));
    EyeLeft->SetRelativeLocation(FVector(46,-20,48));
    BWVisuals::Tint(EyeLeft, FLinearColor(1.f,.02f,.035f), true);
    EyeRight->SetStaticMesh(BWVisuals::Mesh(TEXT("Sphere")));
    EyeRight->SetRelativeScale3D(FVector(.11f,.12f,.11f));
    EyeRight->SetRelativeLocation(FVector(46,20,48));
    BWVisuals::Tint(EyeRight, FLinearColor(1.f,.02f,.035f), true);

    // Imported Whisper skeletal mesh and its own authored materials and animations.
    // The old shadow meshes remain as fallback if assets are unavailable.
    if (USkeletalMesh* Mesh = LoadObject<USkeletalMesh>(nullptr,
        TEXT("/Game/Whisper/Base_Mesh/SK_Whisper.SK_Whisper")))
    {
        DetailedBody->SetSkeletalMesh(Mesh);
        DetailedBody->SetRelativeLocation(FVector(0.f,0.f,-90.f));
        DetailedBody->SetRelativeScale3D(FVector(1.0f));
        DetailedBody->SetVisibility(true);
        Body->SetVisibility(false);
        EyeLeft->SetVisibility(false);
        EyeRight->SetVisibility(false);
        Glow->SetIntensity(350.f);
        IdleAnim = LoadObject<UAnimSequence>(nullptr,
            TEXT("/Game/Whisper/Animations/Anim_Whisper_Idle1.Anim_Whisper_Idle1"));
        RunAnim = LoadObject<UAnimSequence>(nullptr,
            TEXT("/Game/Whisper/Animations/Anim_Whisper_Run.Anim_Whisper_Run"));
        AttackAnim = LoadObject<UAnimSequence>(nullptr,
            TEXT("/Game/Whisper/Animations/Anim_Whisper_Attack1.Anim_Whisper_Attack1"));
        bHasDetailedBody = true;
        if (IdleAnim) DetailedBody->PlayAnimation(IdleAnim,true);
    }
}

void ABWWatcher::UpdateAnimation(bool bChasing)
{
    if (!bHasDetailedBody || AttackAnimationHold > 0.f) return;
    if (bRunAnimation != bChasing)
    {
        bRunAnimation = bChasing;
        if (UAnimSequence* Anim = bChasing ? RunAnim : IdleAnim)
            DetailedBody->PlayAnimation(Anim, true);
    }
}

void ABWWatcher::Tick(float Dt)
{
    Super::Tick(Dt);
    Clock += Dt;
    AttackCooldown = FMath::Max(0.f, AttackCooldown - Dt);
    if (AttackAnimationHold > 0.f)
    {
        AttackAnimationHold = FMath::Max(0.f, AttackAnimationHold-Dt);
        if (AttackAnimationHold <= 0.f)
        {
            bRunAnimation = false;
            if (RunAnim && bHasDetailedBody) DetailedBody->PlayAnimation(RunAnim,true);
            bRunAnimation = true;
        }
    }
    ABWCharacter* Player = Cast<ABWCharacter>(UGameplayStatics::GetPlayerCharacter(this,0));
    if (!Player || Player->IsDead()) return;
    const FVector PlayerPos = Player->GetActorLocation();
    const FVector Here = GetActorLocation();
    const FVector FlatToPlayer(PlayerPos.X-Here.X, PlayerPos.Y-Here.Y, 0.f);
    const float Distance = FlatToPlayer.Size();
    if (Distance < 2400.f)
    {
        UpdateAnimation(true);
        const FVector Direction = FlatToPlayer.GetSafeNormal();
        const FVector LookDir = Player->GetViewForward();
        const FVector ToWatcher = (-Direction);
        const bool bBlinded = Player->IsFlashlightOn() && Distance < 1050.f &&
                              FVector::DotProduct(LookDir, ToWatcher) > 0.87f;
        const float Speed = bBlinded ? 35.f : 150.f;
        const FVector Next = Here + Direction * Speed * Dt;
        bool bProtectedByFire = false;
        for (TActorIterator<ABWCampfire> Fire(GetWorld()); Fire; ++Fire)
        {
            if (FVector::Dist2D(Next,Fire->GetActorLocation()) < 470.f)
            {
                bProtectedByFire = true;
                break;
            }
        }
        // As a supernatural enemy, this prototype intentionally passes through scenery.
        // They are unable to enter the safety radius of a lit campfire.
        const FVector Movement = bProtectedByFire ? Here : Next;
        SetActorLocation(FVector(Movement.X,Movement.Y,Anchor.Z + FMath::Sin(Clock*2.2f)*24.f));
        SetActorRotation(Direction.Rotation());
        if (Distance < 145.f && !bProtectedByFire && AttackCooldown <= 0.f)
        {
            Player->TakeSurvivalDamage(17.f);
            AttackCooldown = 1.8f;
            if (bHasDetailedBody && AttackAnim)
            {
                DetailedBody->PlayAnimation(AttackAnim,false);
                AttackAnimationHold = 0.9f;
            }
        }
    }
    else
    {
        UpdateAnimation(false);
        SetActorLocation(FVector(Here.X,Here.Y,Anchor.Z+FMath::Sin(Clock*1.4f)*20.f));
    }
}

void ABWWatcher::ReceiveMeleeHit()
{
    HitPoints--;
    if (HitPoints <= 0) Destroy();
}
