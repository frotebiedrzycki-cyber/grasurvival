#include "BWRadio.h"
#include "BWVisuals.h"
#include "Components/SceneComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/PointLightComponent.h"

ABWRadio::ABWRadio()
{
    Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root")); RootComponent = Root;
    Panel = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("RadioConsole")); Panel->SetupAttachment(Root);
    Panel->SetCollisionProfileName(TEXT("BlockAll"));
    Antenna = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Antenna")); Antenna->SetupAttachment(Root);
    Antenna->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    StatusLight = CreateDefaultSubobject<UPointLightComponent>(TEXT("SignalLight")); StatusLight->SetupAttachment(Root);
    StatusLight->SetLightColor(FLinearColor(.9f,.03f,.04f));
    StatusLight->SetIntensity(3600);
    StatusLight->SetAttenuationRadius(750);
    StatusLight->SetRelativeLocation(FVector(0,0,250));
}

void ABWRadio::BeginPlay()
{
    Super::BeginPlay();
    Panel->SetStaticMesh(BWVisuals::Mesh(TEXT("Cube")));
    Panel->SetRelativeScale3D(FVector(1.5f,.75f,1.45f));
    Panel->SetRelativeLocation(FVector(0,0,75));
    BWVisuals::Tint(Panel, FLinearColor(.11f,.15f,.16f));
    Antenna->SetStaticMesh(BWVisuals::Mesh(TEXT("Cylinder")));
    Antenna->SetRelativeLocation(FVector(-40,0,375));
    Antenna->SetRelativeScale3D(FVector(.10f,.10f,6.0f));
    BWVisuals::Tint(Antenna, FLinearColor(.22f,.24f,.26f));
}

FString ABWRadio::Prompt() const
{
    return bRepaired ? TEXT("RADIO DZIALA - sygnal wyslany!") : TEXT("[E] Napraw radio: 8 drewna + 5 kamieni");
}

void ABWRadio::SetRepaired()
{
    bRepaired = true;
    StatusLight->SetLightColor(FLinearColor(.03f,1.f,.24f));
    StatusLight->SetIntensity(16000.f);
}
