#include "BWResourceNode.h"
#include "BWVisuals.h"
#include "Components/SceneComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMesh.h"

ABWResourceNode::ABWResourceNode()
{
    PrimaryActorTick.bCanEverTick = false;
    Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
    RootComponent = Root;
    Core = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Core"));
    Core->SetupAttachment(Root);
    Core->SetCollisionProfileName(TEXT("BlockAll"));
    CrownA = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("NeedlesLower"));
    CrownA->SetupAttachment(Root);
    CrownB = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("NeedlesMiddle"));
    CrownB->SetupAttachment(Root);
    CrownC = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("NeedlesTop"));
    CrownC->SetupAttachment(Root);
    CrownA->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    CrownB->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    CrownC->SetCollisionEnabled(ECollisionEnabled::NoCollision);
}

void ABWResourceNode::Configure(EBWResourceType InType, int32 InUses)
{
    ResourceType = InType;
    UsesRemaining = FMath::Max(1, InUses);
    if (InType == EBWResourceType::Wood)
    {
        if (UStaticMesh* Tree = LoadObject<UStaticMesh>(nullptr,
            TEXT("/Game/StyleHex_Studio/Free_Packs/FREE_Stylized_Forest_Sample/Meshes/Trees/SM_Tree_Birch_1.SM_Tree_Birch_1")))
        {
            Core->SetStaticMesh(Tree);
            Core->SetRelativeScale3D(FVector(1.0f));
            Core->SetRelativeLocation(FVector::ZeroVector);
            CrownA->SetVisibility(false);
            CrownB->SetVisibility(false);
            CrownC->SetVisibility(false);
            return;
        }
        Core->SetStaticMesh(BWVisuals::Mesh(TEXT("Cylinder")));
        Core->SetRelativeScale3D(FVector(0.85f, 0.85f, 4.8f));
        Core->SetRelativeLocation(FVector(0, 0, 240));
        BWVisuals::Tint(Core, FLinearColor(0.18f,0.12f,0.09f));
        UStaticMeshComponent* CrownMeshes[] = {CrownA, CrownB, CrownC};
        for (int32 i=0; i<3; i++)
        {
            CrownMeshes[i]->SetStaticMesh(BWVisuals::Mesh(TEXT("Cone")));
            CrownMeshes[i]->SetRelativeLocation(FVector(0,0,340.f + i*120.f));
            CrownMeshes[i]->SetRelativeScale3D(FVector(3.2f-i*0.55f,3.2f-i*0.55f,2.5f));
            BWVisuals::Tint(CrownMeshes[i], FLinearColor(0.025f,0.11f + i*0.012f,0.075f));
        }
    }
    else
    {
        if (UStaticMesh* Rock = LoadObject<UStaticMesh>(nullptr,
            TEXT("/Game/StyleHex_Studio/Free_Packs/FREE_Stylized_Forest_Sample/Meshes/Stones/SM_Stone_2.SM_Stone_2")))
        {
            Core->SetStaticMesh(Rock);
            Core->SetRelativeScale3D(FVector(1.25f));
            Core->SetRelativeLocation(FVector::ZeroVector);
            CrownA->SetVisibility(false);
            CrownB->SetVisibility(false);
            CrownC->SetVisibility(false);
            return;
        }
        Core->SetStaticMesh(BWVisuals::Mesh(TEXT("Sphere")));
        Core->SetRelativeScale3D(FVector(1.8f,1.4f,0.95f));
        Core->SetRelativeLocation(FVector(0,0,45));
        BWVisuals::Tint(Core, FLinearColor(0.20f,0.25f,0.28f));
        CrownA->SetVisibility(false);
        CrownB->SetVisibility(false);
        CrownC->SetVisibility(false);
    }
}

int32 ABWResourceNode::Harvest(EBWResourceType& OutType)
{
    if (UsesRemaining <= 0) return 0;
    OutType = ResourceType;
    UsesRemaining--;
    if (UsesRemaining <= 0) Destroy();
    return 1;
}

FString ABWResourceNode::Prompt() const
{
    return ResourceType == EBWResourceType::Wood
        ? FString::Printf(TEXT("[E] Zbierz drewno (%d)"), UsesRemaining)
        : FString::Printf(TEXT("[E] Zbierz kamien (%d)"), UsesRemaining);
}
