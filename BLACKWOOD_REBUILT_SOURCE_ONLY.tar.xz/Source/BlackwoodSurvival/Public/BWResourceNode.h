#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BWResourceNode.generated.h"

class USceneComponent;
class UStaticMeshComponent;

UENUM(BlueprintType)
enum class EBWResourceType : uint8
{
    Wood UMETA(DisplayName="Drewno"),
    Stone UMETA(DisplayName="Kamien")
};

UCLASS()
class BLACKWOODSURVIVAL_API ABWResourceNode : public AActor
{
    GENERATED_BODY()
public:
    ABWResourceNode();
    void Configure(EBWResourceType InType, int32 InUses);
    int32 Harvest(EBWResourceType& OutType);
    FString Prompt() const;

private:
    UPROPERTY(VisibleAnywhere) USceneComponent* Root;
    UPROPERTY(VisibleAnywhere) UStaticMeshComponent* Core;
    UPROPERTY(VisibleAnywhere) UStaticMeshComponent* CrownA;
    UPROPERTY(VisibleAnywhere) UStaticMeshComponent* CrownB;
    UPROPERTY(VisibleAnywhere) UStaticMeshComponent* CrownC;
    UPROPERTY(EditAnywhere, Category="Resource") EBWResourceType ResourceType = EBWResourceType::Wood;
    UPROPERTY(EditAnywhere, Category="Resource") int32 UsesRemaining = 3;
};
