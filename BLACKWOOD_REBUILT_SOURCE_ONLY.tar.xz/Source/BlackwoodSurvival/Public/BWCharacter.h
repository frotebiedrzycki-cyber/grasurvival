#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "BWCharacter.generated.h"

class UCameraComponent;
class USpringArmComponent;
class USpotLightComponent;
class UStaticMeshComponent;
class UPointLightComponent;

UCLASS()
class BLACKWOODSURVIVAL_API ABWCharacter : public ACharacter
{
    GENERATED_BODY()
public:
    ABWCharacter();
    virtual void BeginPlay() override;
    virtual void Tick(float DeltaSeconds) override;
    virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;

    UPROPERTY(BlueprintReadOnly, Category="Survival") float Health = 100.f;
    UPROPERTY(BlueprintReadOnly, Category="Survival") float Hunger = 100.f;
    UPROPERTY(BlueprintReadOnly, Category="Survival") float Thirst = 100.f;
    UPROPERTY(BlueprintReadOnly, Category="Survival") float Stamina = 100.f;
    UPROPERTY(BlueprintReadOnly, Category="Survival") float Battery = 100.f;
    UPROPERTY(BlueprintReadOnly, Category="Inventory") int32 Wood = 0;
    UPROPERTY(BlueprintReadOnly, Category="Inventory") int32 Stone = 0;
    UPROPERTY(BlueprintReadOnly, Category="Inventory") int32 Berries = 0;
    UPROPERTY(BlueprintReadOnly, Category="Inventory") int32 Water = 0;

    int32 GetSelectedHotbarSlot() const { return SelectedHotbarSlot; }
    bool IsPistolReloading() const { return ReloadRemaining > 0.f; }
    int32 GetAmmoInMagazine() const { return AmmoInMagazine; }
    int32 GetReserveAmmo() const { return ReserveAmmo; }
    FString GetHotbarItemName(int32 Index) const;
    int32 GetHotbarItemCount(int32 Index) const;
    bool HasHotbarItem(int32 Index) const;

    bool IsFlashlightOn() const { return bFlashlightOn; }
    bool IsInventoryOpen() const { return bInventory; }
    bool IsDead() const { return bDead; }
    bool HasRepairedRadio() const { return bRadioRepaired; }
    FVector GetViewForward() const;
    FString GetInteractionPrompt() const;
    FString GetMessage() const { return MessageDuration > 0.f ? FeedbackMessage : FString(); }
    void TakeSurvivalDamage(float Amount);

private:
    UPROPERTY(VisibleAnywhere, Category="Camera") UCameraComponent* Camera;
    UPROPERTY(VisibleAnywhere, Category="Camera") USpringArmComponent* CameraBoom;
    UPROPERTY(VisibleAnywhere, Category="Appearance") UStaticMeshComponent* CharacterDisplay;
    bool bThirdPerson = false;
    void ToggleCameraMode();
    UPROPERTY(VisibleAnywhere, Category="Light") USpotLightComponent* Flashlight;
    UPROPERTY(VisibleAnywhere, Category="Equipment") UStaticMeshComponent* ToolHandle;
    UPROPERTY(VisibleAnywhere, Category="Equipment") UStaticMeshComponent* ToolHead;
    UPROPERTY(VisibleAnywhere, Category="Equipment") UPointLightComponent* MuzzleFlash;
    UPROPERTY(BlueprintReadOnly, Category="Combat", meta=(AllowPrivateAccess="true")) int32 AmmoInMagazine = 12;
    UPROPERTY(BlueprintReadOnly, Category="Combat", meta=(AllowPrivateAccess="true")) int32 ReserveAmmo = 36;
    float ReloadRemaining = 0.f;
    float MuzzleFlashRemaining = 0.f;
    void ReloadPistol();
    void FirePistol();
    int32 SelectedHotbarSlot = 3; // 0..9 corresponds to number keys 1..0
    FVector SafeRespawnLocation = FVector(0.f,0.f,190.f);
    void UpdateHeldTool();
    void SelectHotbar(int32 Index);
    void Hotbar1(); void Hotbar2(); void Hotbar3(); void Hotbar4(); void Hotbar5();
    void Hotbar6(); void Hotbar7(); void Hotbar8(); void Hotbar9(); void Hotbar0();

    bool bFlashlightOn = false;
    bool bInventory = false;
    bool bSprinting = false;
    bool bDead = false;
    bool bRadioRepaired = false;
    float AttackCooldown = 0.f;
    float MessageDuration = 0.f;
    FString FeedbackMessage = TEXT("Znajdz stacje radiowa. Przetrwaj noc.");

    void Forward(float Amount);
    void Right(float Amount);
    void Turn(float Amount);
    void Look(float Amount);
    void StartSprint();
    void StopSprint();
    void ToggleCrouch();
    void ToggleFlashlight();
    void ToggleInventory();
    void Interact();
    void Attack();
    void BuildCampfire();
    void Eat();
    void Drink();
    void Respawn();
    AActor* TraceLook(float Range) const;
    void Notify(const FString& Text, float Seconds=3.f);
};
