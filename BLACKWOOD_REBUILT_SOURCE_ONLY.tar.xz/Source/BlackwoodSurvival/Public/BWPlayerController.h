#pragma once
#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "BWPlayerController.generated.h"

class UBWMainMenuWidget;

UCLASS()
class BLACKWOODSURVIVAL_API ABWPlayerController : public APlayerController
{
    GENERATED_BODY()
public:
    virtual void BeginPlay() override;
    virtual void SetupInputComponent() override;
    UFUNCTION(BlueprintCallable, Category="BLACKWOOD") void StartGame();
    UFUNCTION(BlueprintCallable, Category="BLACKWOOD") void ShowMainMenu();
    UFUNCTION(BlueprintCallable, Category="BLACKWOOD") void QuitGame();
    bool IsMenuOpen() const { return bMenuOpen; }
private:
    UPROPERTY(Transient) UBWMainMenuWidget* MenuWidget = nullptr;
    bool bMenuOpen = false;
    void ToggleMenu();
};
