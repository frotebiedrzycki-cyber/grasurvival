#pragma once
#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "BWMainMenuWidget.generated.h"

UCLASS()
class BLACKWOODSURVIVAL_API UBWMainMenuWidget : public UUserWidget
{
    GENERATED_BODY()
protected:
    virtual void NativeOnInitialized() override;
private:
    UFUNCTION() void HandlePlay();
    UFUNCTION() void HandleQuit();
};
