#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BWWorldDirector.generated.h"

class USceneComponent;
class UInstancedStaticMeshComponent;
class UStaticMeshComponent;

UCLASS()
class BLACKWOODSURVIVAL_API ABWWorldDirector : public AActor
{
    GENERATED_BODY()
public:
    ABWWorldDirector();
    virtual void BeginPlay() override;
private:
    UPROPERTY(VisibleAnywhere) USceneComponent* Root;
    UPROPERTY(VisibleAnywhere) UInstancedStaticMeshComponent* ForestTrunks;
    UPROPERTY(VisibleAnywhere) UInstancedStaticMeshComponent* ForestCanopies;
    UPROPERTY(VisibleAnywhere) UInstancedStaticMeshComponent* ForestRocks;
    UPROPERTY(VisibleAnywhere) UInstancedStaticMeshComponent* ForestStumps;
    UPROPERTY(VisibleAnywhere) UInstancedStaticMeshComponent* ForestBroadleaf;
    UPROPERTY(VisibleAnywhere) UInstancedStaticMeshComponent* ForestBoulders;
    UPROPERTY(VisibleAnywhere) UInstancedStaticMeshComponent* ForestBushes;
    UPROPERTY(VisibleAnywhere) UInstancedStaticMeshComponent* ForestGrass;
    UPROPERTY(VisibleAnywhere) UInstancedStaticMeshComponent* ForestFlowers;
    void GenerateScene();
    void SpawnBox(const FVector& Position, const FVector& Size, const FLinearColor& Color,
                  const FRotator& Rotation=FRotator::ZeroRotator);
};
