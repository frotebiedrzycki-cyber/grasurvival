#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BWCampfire.generated.h"

class USceneComponent;
class UStaticMeshComponent;
class UPointLightComponent;

UCLASS()
class BLACKWOODSURVIVAL_API ABWCampfire : public AActor
{
    GENERATED_BODY()
public:
    ABWCampfire();
    virtual void Tick(float DeltaSeconds) override;
    virtual void BeginPlay() override;
private:
    UPROPERTY(VisibleAnywhere) USceneComponent* Root;
    UPROPERTY(VisibleAnywhere) UStaticMeshComponent* Stones;
    UPROPERTY(VisibleAnywhere) UStaticMeshComponent* Wood;
    UPROPERTY(VisibleAnywhere) UStaticMeshComponent* Flame;
    UPROPERTY(VisibleAnywhere) UPointLightComponent* FireLight;
    float Clock = 0;
};
