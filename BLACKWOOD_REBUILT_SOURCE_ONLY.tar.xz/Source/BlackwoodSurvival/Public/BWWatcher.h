#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BWWatcher.generated.h"

class USphereComponent;
class UStaticMeshComponent;
class UPointLightComponent;
class USkeletalMeshComponent;
class UAnimSequence;

UCLASS()
class BLACKWOODSURVIVAL_API ABWWatcher : public AActor
{
    GENERATED_BODY()
public:
    ABWWatcher();
    virtual void BeginPlay() override;
    virtual void Tick(float DeltaSeconds) override;
    void ReceiveMeleeHit();
private:
    UPROPERTY(VisibleAnywhere) USphereComponent* Collision;
    UPROPERTY(VisibleAnywhere) UStaticMeshComponent* Body;
    UPROPERTY(VisibleAnywhere) UStaticMeshComponent* EyeLeft;
    UPROPERTY(VisibleAnywhere) UStaticMeshComponent* EyeRight;
    UPROPERTY(VisibleAnywhere) UPointLightComponent* Glow;
    UPROPERTY(VisibleAnywhere) USkeletalMeshComponent* DetailedBody;
    UPROPERTY(Transient) UAnimSequence* IdleAnim = nullptr;
    UPROPERTY(Transient) UAnimSequence* RunAnim = nullptr;
    UPROPERTY(Transient) UAnimSequence* AttackAnim = nullptr;
    bool bHasDetailedBody = false;
    bool bRunAnimation = false;
    float AttackAnimationHold = 0.f;
    void UpdateAnimation(bool bChasing);
    FVector Anchor = FVector::ZeroVector;
    float Clock = 0.f;
    float AttackCooldown = 0.f;
    int32 HitPoints = 3;
};
