#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BWPickup.generated.h"

class USceneComponent;
class UStaticMeshComponent;
class UPointLightComponent;

UENUM(BlueprintType)
enum class EBWPickupType : uint8 { Berries, Water };

UCLASS()
class BLACKWOODSURVIVAL_API ABWPickup : public AActor
{
    GENERATED_BODY()
public:
    ABWPickup();
    void Configure(EBWPickupType InType);
    EBWPickupType GetPickupType() const { return PickupType; }
    FString Prompt() const;
private:
    UPROPERTY(VisibleAnywhere) USceneComponent* Root;
    UPROPERTY(VisibleAnywhere) UStaticMeshComponent* Mesh;
    UPROPERTY(EditAnywhere, Category="Pickup") EBWPickupType PickupType = EBWPickupType::Berries;
};
