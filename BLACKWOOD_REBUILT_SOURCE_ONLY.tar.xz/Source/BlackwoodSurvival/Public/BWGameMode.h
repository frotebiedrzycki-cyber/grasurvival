#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "BWGameMode.generated.h"

UCLASS()
class BLACKWOODSURVIVAL_API ABWGameMode : public AGameModeBase
{
    GENERATED_BODY()
public:
    ABWGameMode();
    virtual void BeginPlay() override;
    virtual void RestartPlayer(AController* NewPlayer) override;
};
