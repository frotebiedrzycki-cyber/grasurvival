#pragma once
#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "BWHUD.generated.h"

UCLASS()
class BLACKWOODSURVIVAL_API ABWHUD : public AHUD
{
    GENERATED_BODY()
public:
    virtual void DrawHUD() override;
private:
    void Bar(float X, float Y, float Width, const FString& Label, float Amount, const FLinearColor& Color);
};
