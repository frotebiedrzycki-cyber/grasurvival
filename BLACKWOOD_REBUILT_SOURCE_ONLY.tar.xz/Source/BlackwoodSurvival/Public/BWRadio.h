#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BWRadio.generated.h"

class USceneComponent;
class UStaticMeshComponent;
class UPointLightComponent;

UCLASS()
class BLACKWOODSURVIVAL_API ABWRadio : public AActor
{
    GENERATED_BODY()
public:
    ABWRadio();
    virtual void BeginPlay() override;
    FString Prompt() const;
    bool IsRepaired() const { return bRepaired; }
    void SetRepaired();
private:
    UPROPERTY(VisibleAnywhere) USceneComponent* Root;
    UPROPERTY(VisibleAnywhere) UStaticMeshComponent* Panel;
    UPROPERTY(VisibleAnywhere) UStaticMeshComponent* Antenna;
    UPROPERTY(VisibleAnywhere) UPointLightComponent* StatusLight;
    bool bRepaired = false;
};
