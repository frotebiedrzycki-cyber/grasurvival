# BLACKWOOD Lost Signal - naprawa niepoprawnego kodowania .uproject
# Kliknij prawym przyciskiem -> Uruchom przy uzyciu PowerShell
# Lub uruchom w PowerShell: powershell -ExecutionPolicy Bypass -File .\NaprawProjekt.ps1
$ErrorActionPreference = 'Stop'
try {
    $root = Split-Path -Parent $MyInvocation.MyCommand.Path
    $project = Join-Path $root 'BlackwoodSurvival.uproject'

    # Zostawiamy kopie lokalnego pliku (nawet jesli jest uszkodzony).
    if (Test-Path -LiteralPath $project) {
        $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
        Copy-Item -LiteralPath $project -Destination (Join-Path $root ('BlackwoodSurvival.uproject.backup_' + $stamp)) -Force
    }

    # Doslownie poprawny deskryptor - unika zmian kodowania przez edytory Windows.
    $json = @'
{
  "FileVersion": 3,
  "EngineAssociation": "5.8",
  "Category": "Games",
  "Description": "BLACKWOOD: Lost Signal - survival horror FPP / prototype v0.1.1",
  "Modules": [
    { "Name": "BlackwoodSurvival", "Type": "Runtime", "LoadingPhase": "Default" }
  ],
  "Plugins": [
    { "Name": "PythonScriptPlugin", "Enabled": true, "SupportedTargetPlatforms": ["Win64", "Mac", "Linux"] }
  ]
}
'@
    $enc = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($project, $json + "`n", $enc)
    $bytes = [System.IO.File]::ReadAllBytes($project)
    if ($bytes.Length -lt 10 -or $bytes[0] -ne 123) { throw 'Niepoprawny poczatek pliku.' }
    $data = Get-Content -LiteralPath $project -Encoding UTF8 -Raw | ConvertFrom-Json
    if ($data.Modules[0].Name -ne 'BlackwoodSurvival') { throw 'Niepoprawny modul.' }
    Write-Host 'OK: BlackwoodSurvival.uproject zapisany w UTF-8 bez BOM. Mozesz wygenerowac pliki Visual Studio.' -ForegroundColor Green
    Write-Host 'Jesli teraz Unreal zglasza Win64 SDK - zainstaluj narzedzia Visual Studio / Windows SDK.' -ForegroundColor Yellow
} catch {
    Write-Host "BLAD: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
Read-Host 'Nacisnij ENTER aby zamknac'
