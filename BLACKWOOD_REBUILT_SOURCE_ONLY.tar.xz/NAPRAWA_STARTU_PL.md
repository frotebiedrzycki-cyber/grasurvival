# BLACKWOOD v0.1.1 - NAPRAWA OTWIERANIA UE 5.8

Wariant naprawczy projektu źródłowego v0.1. Kod gry i mechaniki pozostały bez zmian.

## Błąd: '0xFF' is an invalid start of a value

Powód: lokalny plik `BlackwoodSurvival.uproject` jest odczytywany jako nieprawidłowy JSON. W tym ZIP-ie jest on **UTF-8 bez BOM**, pierwszy bajt pliku to `0x7B` (znak `{`).

1. Rozpakuj ten ZIP do *NOWEGO* folderu, np. `C:\UEProjects\BlackwoodSurvival_v0.1.1\`.
2. Nie kopiuj starego uszkodzonego `BlackwoodSurvival.uproject` do tego folderu.
3. W razie potrzeby kliknij prawym przyciskiem plik `NaprawProjekt.ps1` → Uruchom w PowerShell (albo z konsoli: `powershell -ExecutionPolicy Bypass -File .\NaprawProjekt.ps1`). Skrypt tworzy kopię zapasową starego `.uproject` i przywraca poprawny UTF-8.
4. Kliknij prawym na `BlackwoodSurvival.uproject` → Generate Visual Studio project files.
5. Jeżeli pojawi się komunikat `Some Platforms were skipped due to invalid SDK setup: Win64`, uruchom *Visual Studio Installer* → Modyfikuj → zaznacz `Game development with C++` i `Desktop development with C++`, właściwy toolset MSVC i Windows SDK. Dla **UE 5.8** wymagany SDK Windows to co najmniej `10.0.22621.0`, zalecany `10.0.26100.0`. Obsługiwane VS 2022 17.14+ lub VS 2026 18.0+.
6. Po instalacji narzędzi ponów generowanie plików projektu i kompilację `Development Editor` + `Win64`.

Jeżeli system lub UE dalej zgłasza błąd, zachowaj dokładny log `Saved/Logs/*.log` i prześlij treść nowego błędu.

## Kontrola pliku

- `BlackwoodSurvival.uproject` rozpoczyna się od `{`, hex `7B 0A 20 20 ...`; nie od `FF FE`.
- Po rozpakowaniu możesz uruchomić `python Scripts/StaticCheck.py` (kontrola struktury, nie kompilacja UE).

Dokumentacja Epic UE 5.8: https://dev.epicgames.com/documentation/pt-br/unreal-engine/setting-up-visual-studio-development-environment-for-cplusplus-projects-in-unreal-engine

**Nie jest to plik EXE.** W tym środowisku nie mam UE5 do kompilacji i testowania w edytorze. Ta paczka usuwa znaną przeszkodę z kodowaniem; inne błędy kompilacji mogą się jeszcze ujawnić.
