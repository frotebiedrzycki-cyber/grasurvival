"""Offline structural checks. Run from any working directory.

These tests cannot replace an Unreal 5.8 C++ build and PIE runtime test.
"""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
project = ROOT / 'BlackwoodSurvival.uproject'
raw = project.read_bytes()
assert raw.startswith(b'{') and not raw.startswith(b'\xef\xbb\xbf')
meta = json.loads(raw.decode('utf-8'))
assert meta['EngineAssociation'] == '5.8'
assert meta['Modules'][0]['Name'] == 'BlackwoodSurvival'
ini = (ROOT / 'Config/DefaultEngine.ini').read_text('utf-8')
assert 'GameDefaultMap=/Engine/Maps/Entry' in ini
assert 'GlobalDefaultGameMode=/Script/BlackwoodSurvival.BWGameMode' in ini
assert '/Levels/World_Demo' not in ini, 'The demo map must not be default!'
inputs = (ROOT / 'Config/DefaultInput.ini').read_text('utf-8')
for action in ('MoveForward','MoveRight','Turn','LookUp','Inventory','Hotbar1','Hotbar2',
               'Hotbar3','Hotbar4','Hotbar5','Hotbar6','Hotbar7','Hotbar8','Hotbar9',
               'Hotbar0','Attack','PauseMenu','CameraMode','Respawn'):
    assert f'"{action}"' in inputs, action
src = ROOT/'Source/BlackwoodSurvival'
for path in list(src.rglob('*.cpp')) + list(src.rglob('*.h')):
    data = path.read_bytes().decode('utf-8')
    assert data.count('{') == data.count('}'), path
    if path.suffix=='.h' and 'UCLASS()' in data:
        assert f'#include "{path.stem}.generated.h"' in data
mode=(src/'Private/BWGameMode.cpp').read_text('utf-8')
assert 'DefaultPawnClass = ABWCharacter::StaticClass()' in mode
assert 'PlayerControllerClass = ABWPlayerController::StaticClass()' in mode
assert 'HUDClass = ABWHUD::StaticClass()' in mode
controller=(src/'Private/BWPlayerController.cpp').read_text('utf-8')
assert 'ShowMainMenu()' in controller and 'StartGame()' in controller
assert 'PC->Possess(Character)' in mode
assert 'RestartPlayer(this)' in controller
hud=(src/'Private/BWHUD.cpp').read_text('utf-8')
assert 'IsInventoryOpen()' in hud and 'GetHotbarItemName' in hud
char=(src/'Private/BWCharacter.cpp').read_text('utf-8')
assert 'FirePistol()' in char and 'SelectHotbar(' in char
build=(src/'BlackwoodSurvival.Build.cs').read_text('utf-8')
assert all(x in build for x in ('"UMG"', '"Slate"', '"SlateCore"'))
assert (src/'Private/BWMainMenuWidget.cpp').is_file()
print('PASS: project JSON, safe map, GameMode/controller/pawn/HUD, UMG, menu, inventory, hotbar and pistol mappings')
print('NOT TESTED: UnrealBuildTool compile, PIE gameplay, full Windows executable packaging')
