# BLACKWOOD v0.5.3: Import user-supplied Nulla FBX as a non-rigged static mesh.
# UE5 Editor -> Tools -> Execute Python Script -> Scripts/IMPORT_NULLA.py
# This imports the character AS AN UNANIMATED STATIC MESH only.
from pathlib import Path
import unreal

ROOT = Path(__file__).resolve().parent.parent
FBX = ROOT / "ExternalAssets" / "Nulla" / "source" / "Nulla.fbx"
TEXTURES = ROOT / "ExternalAssets" / "Nulla" / "textures"
DEST = "/Game/Blackwood/Player"
ASSETS = unreal.EditorAssetLibrary

def message(s):
    unreal.log("[BLACKWOOD NULLA] " + s)

if not FBX.exists():
    raise RuntimeError("FBX file missing: {}".format(FBX))

if not ASSETS.does_directory_exist(DEST):
    ASSETS.make_directory(DEST)
if not ASSETS.does_directory_exist(DEST + "/Textures"):
    ASSETS.make_directory(DEST + "/Textures")

# Import textures explicitly as a fallback if FBX texture references do not resolve.
texture_tasks = []
for texture in sorted(TEXTURES.glob("*.png")):
    target = DEST + "/Textures/" + texture.stem
    if ASSETS.does_asset_exist(target):
        continue
    t = unreal.AssetImportTask()
    t.set_editor_property("filename", str(texture))
    t.set_editor_property("destination_path", DEST + "/Textures")
    t.set_editor_property("destination_name", texture.stem)
    t.set_editor_property("automated", True)
    t.set_editor_property("replace_existing", False)
    t.set_editor_property("save", True)
    texture_tasks.append(t)
if texture_tasks:
    unreal.AssetToolsHelpers.get_asset_tools().import_asset_tasks(texture_tasks)
message("Texture import done ({} new files)".format(len(texture_tasks)))

MESH_PATH = DEST + "/SM_Nulla"
if not ASSETS.does_asset_exist(MESH_PATH):
    options = unreal.FbxImportUI()
    options.set_editor_property("import_mesh", True)
    options.set_editor_property("import_as_skeletal", False)
    options.set_editor_property("import_materials", True)
    options.set_editor_property("import_textures", True)
    options.set_editor_property("import_animations", False)
    options.set_editor_property("automated_import_should_detect_type", False)
    options.set_editor_property("mesh_type_to_import", unreal.FBXImportType.FBXIT_STATIC_MESH)
    options.static_mesh_import_data.set_editor_property("combine_meshes", True)
    options.static_mesh_import_data.set_editor_property("auto_generate_collision", False)

    t = unreal.AssetImportTask()
    t.set_editor_property("filename", str(FBX))
    t.set_editor_property("destination_path", DEST)
    t.set_editor_property("destination_name", "SM_Nulla")
    t.set_editor_property("automated", True)
    t.set_editor_property("replace_existing", False)
    t.set_editor_property("save", True)
    t.set_editor_property("options", options)
    unreal.AssetToolsHelpers.get_asset_tools().import_asset_tasks([t])

    if not ASSETS.does_asset_exist(MESH_PATH):
        paths = list(t.get_editor_property("imported_object_paths"))
        mesh_candidates = []
        for path in paths:
            asset = ASSETS.load_asset(path)
            if isinstance(asset, unreal.StaticMesh):
                mesh_candidates.append(path)
        if len(mesh_candidates) == 1:
            ASSETS.rename_asset(mesh_candidates[0], MESH_PATH)

mesh = ASSETS.load_asset(MESH_PATH)
if not mesh:
    raise RuntimeError("Could not create {}. Read Output Log for FBX importer errors.".format(MESH_PATH))
if not isinstance(mesh, unreal.StaticMesh):
    raise RuntimeError("Nulla asset is not a StaticMesh: {}".format(mesh.get_class().get_name()))

ASSETS.save_loaded_asset(mesh)
message("SUCCESS! Player mesh available at {}".format(MESH_PATH))
message("Stop and restart Play to see it. The model has no skeleton/animations.")
