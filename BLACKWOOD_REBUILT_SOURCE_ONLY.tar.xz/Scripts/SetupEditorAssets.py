# Run in Unreal Editor via Tools > Execute Python Script.
# Creates BLACKWOOD materials and imports original audio assets.
from pathlib import Path
import unreal
import sys

here = Path(__file__).resolve().parent
sys.path.insert(0, str(here))
import CreateMaterials  # noqa: F401

AUDIO_FILES = {
    'blackwood_night_ambience.wav': {'dest_name': 'blackwood_night_ambience', 'looping': True},
    'blackwood_flashlight_click.wav': {'dest_name': 'blackwood_flashlight_click', 'looping': False},
    'blackwood_pickup.wav': {'dest_name': 'blackwood_pickup', 'looping': False},
    'blackwood_attack.wav': {'dest_name': 'blackwood_attack', 'looping': False},
    'blackwood_damage.wav': {'dest_name': 'blackwood_damage', 'looping': False},
    'blackwood_radio_fixed.wav': {'dest_name': 'blackwood_radio_fixed', 'looping': False},
    'blackwood_pistol_shot.wav': {'dest_name': 'blackwood_pistol_shot', 'looping': False},
    'blackwood_pistol_reload.wav': {'dest_name': 'blackwood_pistol_reload', 'looping': False},
}

def import_wave(filename, dest_name, looping=False):
    wave = here.parent / 'ExternalAssets' / filename
    if not wave.exists():
        unreal.log_warning(f'[BLACKWOOD] Missing sound file: {wave}')
        return
    dest = '/Game/Audio'
    asset_path = dest + '/' + dest_name
    if not unreal.EditorAssetLibrary.does_asset_exist(asset_path):
        task = unreal.AssetImportTask()
        task.set_editor_property('filename', str(wave))
        task.set_editor_property('destination_path', dest)
        task.set_editor_property('destination_name', dest_name)
        task.set_editor_property('automated', True)
        task.set_editor_property('save', True)
        unreal.AssetToolsHelpers.get_asset_tools().import_asset_tasks([task])
    sound = unreal.EditorAssetLibrary.load_asset(asset_path)
    if sound:
        try:
            sound.set_editor_property('looping', looping)
            unreal.EditorAssetLibrary.save_loaded_asset(sound)
        except Exception as ex:
            unreal.log_warning(f'[BLACKWOOD] Could not set looping on {asset_path}: {ex}')
        unreal.log(f'[BLACKWOOD] Imported {asset_path}')
    else:
        unreal.log_warning(f'[BLACKWOOD] Import failed for {asset_path}')

for filename, cfg in AUDIO_FILES.items():
    import_wave(filename, cfg['dest_name'], cfg['looping'])

unreal.log('[BLACKWOOD] Audio + material setup finished.')
