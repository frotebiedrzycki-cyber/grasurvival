"""Unreal Engine 5.8: Tools / Narzedzia -> Execute Python Script.

This fixes the map-specific GameMode override that prevents our player/HUD from
spawning when using a third-party example map. Run once after the C++ rebuild.
"""
import unreal

MAP = '/Game/StyleHex_Studio/Free_Packs/FREE_Stylized_Forest_Sample/Levels/World_Demo'
GAME_MODE = '/Script/BlackwoodSurvival.BWGameMode'

unreal.log('[BLACKWOOD v0.5] Preparing map GameMode fix...')

mode_class = unreal.load_class(None, GAME_MODE)
if not mode_class:
    raise RuntimeError(
        'BWGameMode class is not loaded. Rebuild the C++ project first, restart Unreal, then run this script.')

level_subsystem = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
if not level_subsystem.load_level(MAP):
    raise RuntimeError('Could not open World_Demo. Verify that the StyleHex forest assets are present.')

editor_subsystem = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem)
world = editor_subsystem.get_editor_world()
if not world:
    raise RuntimeError('Unreal editor world is not available. Stop PIE before executing this script.')

settings = world.get_world_settings()
old_mode = settings.get_editor_property('default_game_mode')
unreal.log('[BLACKWOOD v0.5] Original map GameMode: {}'.format(old_mode))
settings.set_editor_property('default_game_mode', mode_class)
if not level_subsystem.save_current_level():
    raise RuntimeError('Could not save the map with the new GameMode override.')

unreal.log('[BLACKWOOD v0.5] SUCCESS: World_Demo now uses BWGameMode. Press Play (Alt+P).')
