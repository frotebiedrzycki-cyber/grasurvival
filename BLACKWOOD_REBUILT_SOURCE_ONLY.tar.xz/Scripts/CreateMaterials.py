# BLACKWOOD / editor-only optional visual pass
# Unreal Editor > Tools > Execute Python Script > choose SetupEditorAssets.py
# Requires Python Editor Script Plugin.
import unreal

ROOT = '/Game/Materials'
EDITOR = unreal.MaterialEditingLibrary
ASSETS = unreal.EditorAssetLibrary
TOOLS = unreal.AssetToolsHelpers.get_asset_tools()


def ensure_root():
    if not ASSETS.does_directory_exist(ROOT):
        ASSETS.make_directory(ROOT)


def create_material(name, emissive=False):
    ensure_root()
    path = f'{ROOT}/{name}'
    if ASSETS.does_asset_exist(path):
        unreal.log(f'[BLACKWOOD] {name} already exists')
        return

    mat = TOOLS.create_asset(name, ROOT, unreal.Material, unreal.MaterialFactoryNew())
    if not mat:
        raise RuntimeError(f'Could not create {path}')

    color = EDITOR.create_material_expression(mat, unreal.MaterialExpressionVectorParameter, -700, -220)
    color.set_editor_property('parameter_name', 'Tint')
    color.set_editor_property('default_value', unreal.LinearColor(0.08, 0.16, 0.14, 1.0))

    brightness = EDITOR.create_material_expression(mat, unreal.MaterialExpressionScalarParameter, -700, -120)
    brightness.set_editor_property('parameter_name', 'Brightness')
    brightness.set_editor_property('default_value', 1.0)

    multiply = EDITOR.create_material_expression(mat, unreal.MaterialExpressionMultiply, -360, -190)
    EDITOR.connect_material_expressions(color, '', multiply, 'A')
    EDITOR.connect_material_expressions(brightness, '', multiply, 'B')
    EDITOR.connect_material_property(multiply, '', unreal.MaterialProperty.MP_BASE_COLOR)

    rough = EDITOR.create_material_expression(mat, unreal.MaterialExpressionScalarParameter, -700, 40)
    rough.set_editor_property('parameter_name', 'Roughness')
    rough.set_editor_property('default_value', 0.88)
    EDITOR.connect_material_property(rough, '', unreal.MaterialProperty.MP_ROUGHNESS)

    spec = EDITOR.create_material_expression(mat, unreal.MaterialExpressionScalarParameter, -700, 120)
    spec.set_editor_property('parameter_name', 'Specular')
    spec.set_editor_property('default_value', 0.14)
    EDITOR.connect_material_property(spec, '', unreal.MaterialProperty.MP_SPECULAR)

    fresnel = EDITOR.create_material_expression(mat, unreal.MaterialExpressionFresnel, -700, 260)
    fresnel.set_editor_property('exponent', 3.0)
    fresnel.set_editor_property('base_reflect_fraction', 0.02)
    rim_strength = EDITOR.create_material_expression(mat, unreal.MaterialExpressionScalarParameter, -700, 360)
    rim_strength.set_editor_property('parameter_name', 'RimStrength')
    rim_strength.set_editor_property('default_value', 0.18 if not emissive else 0.5)
    rim_mul = EDITOR.create_material_expression(mat, unreal.MaterialExpressionMultiply, -360, 310)
    rim_tint = EDITOR.create_material_expression(mat, unreal.MaterialExpressionMultiply, -120, 250)
    EDITOR.connect_material_expressions(fresnel, '', rim_mul, 'A')
    EDITOR.connect_material_expressions(rim_strength, '', rim_mul, 'B')
    EDITOR.connect_material_expressions(rim_mul, '', rim_tint, 'A')
    EDITOR.connect_material_expressions(color, '', rim_tint, 'B')

    if emissive:
        scalar = EDITOR.create_material_expression(mat, unreal.MaterialExpressionScalarParameter, -360, 430)
        scalar.set_editor_property('parameter_name', 'Strength')
        scalar.set_editor_property('default_value', 7.5)
        glow = EDITOR.create_material_expression(mat, unreal.MaterialExpressionMultiply, -120, 420)
        final_em = EDITOR.create_material_expression(mat, unreal.MaterialExpressionAdd, 110, 325)
        EDITOR.connect_material_expressions(color, '', glow, 'A')
        EDITOR.connect_material_expressions(scalar, '', glow, 'B')
        EDITOR.connect_material_expressions(glow, '', final_em, 'A')
        EDITOR.connect_material_expressions(rim_tint, '', final_em, 'B')
        EDITOR.connect_material_property(final_em, '', unreal.MaterialProperty.MP_EMISSIVE_COLOR)
    else:
        EDITOR.connect_material_property(rim_tint, '', unreal.MaterialProperty.MP_EMISSIVE_COLOR)

    EDITOR.recompile_material(mat)
    ASSETS.save_loaded_asset(mat)
    unreal.log(f'[BLACKWOOD] Created {path}')


create_material('M_BWTint')
create_material('M_BWGlow', emissive=True)
unreal.log('[BLACKWOOD] Material setup finished.')


# v0.3: ground using a shipped source texture (no Megascans download required).
# Fail softly: forest meshes and original audio must remain usable if this optional
# editor automation differs in a future UE version.
def create_forest_ground():
    name = 'M_BWGround'
    path = f'{ROOT}/{name}'
    if ASSETS.does_asset_exist(path):
        unreal.log('[BLACKWOOD] Ground material already exists')
        return
    tex = ASSETS.load_asset(
        '/Game/StyleHex_Studio/Free_Packs/FREE_Stylized_Forest_Sample/Textures/Stones/T_Stone_Set_1_BC')
    if not tex:
        unreal.log_warning('[BLACKWOOD] Ground texture not available. Skipping M_BWGround.')
        return

    mat = TOOLS.create_asset(name, ROOT, unreal.Material, unreal.MaterialFactoryNew())
    if not mat:
        raise RuntimeError('Could not create M_BWGround')
    coords = EDITOR.create_material_expression(mat, unreal.MaterialExpressionTextureCoordinate, -600, -180)
    coords.set_editor_property('u_tiling', 36.0)
    coords.set_editor_property('v_tiling', 36.0)
    texture = EDITOR.create_material_expression(mat, unreal.MaterialExpressionTextureSample, -380, -180)
    texture.set_editor_property('texture', tex)
    EDITOR.connect_material_expressions(coords, '', texture, 'Coordinates')

    tint = EDITOR.create_material_expression(mat, unreal.MaterialExpressionVectorParameter, -380, 100)
    tint.set_editor_property('parameter_name', 'GroundTint')
    tint.set_editor_property('default_value', unreal.LinearColor(0.32, 0.40, 0.34, 1.0))
    mul = EDITOR.create_material_expression(mat, unreal.MaterialExpressionMultiply, -80, -160)
    EDITOR.connect_material_expressions(texture, 'RGB', mul, 'A')
    EDITOR.connect_material_expressions(tint, '', mul, 'B')
    EDITOR.connect_material_property(mul, '', unreal.MaterialProperty.MP_BASE_COLOR)
    rough = EDITOR.create_material_expression(mat, unreal.MaterialExpressionConstant, -80, 130)
    rough.set_editor_property('r', .94)
    EDITOR.connect_material_property(rough, '', unreal.MaterialProperty.MP_ROUGHNESS)
    EDITOR.recompile_material(mat)
    ASSETS.save_loaded_asset(mat)
    unreal.log('[BLACKWOOD] M_BWGround saved')

try:
    create_forest_ground()
except Exception as err:
    unreal.log_warning(f'[BLACKWOOD] Optional ground creation failed: {err}')
