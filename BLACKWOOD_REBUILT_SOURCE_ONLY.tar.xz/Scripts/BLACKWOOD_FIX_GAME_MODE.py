# BLACKWOOD v0.5.2 / Unreal Engine 5.8 Editor setup
# Run from: Tools -> Execute Python Script -> Scripts/BLACKWOOD_FIX_GAME_MODE.py
# IMPORTANT: Stop PIE / Simulate before running.
# Creates our OWN playable map based on StyleHex World_Demo. Does not edit the original Fab map.

import re
from pathlib import Path
import unreal

SOURCE_MAP = '/Game/StyleHex_Studio/Free_Packs/FREE_Stylized_Forest_Sample/Levels/World_Demo'
DESTINATION_MAP = '/Game/Blackwood/Maps/BW_PlayableForest'
BW_GAMEMODE = '/Script/BlackwoodSurvival.BWGameMode'
BW_PAWN = '/Script/BlackwoodSurvival.BWCharacter'
BW_HUD = '/Script/BlackwoodSurvival.BWHUD'
BW_START_TAG = 'BW_PLAYER_START'


def info(message):
    unreal.log('[BLACKWOOD SPAWN FIX] ' + str(message))


def fail(message):
    unreal.log_error('[BLACKWOOD SPAWN FIX] ' + str(message))
    raise RuntimeError(message)


info('Starting: generate dedicated playable forest map...')
level_system = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
if level_system.is_in_play_in_editor():
    fail('Stop Play/Simulate first, then run this script again.')

mode_class = unreal.load_class(None, BW_GAMEMODE)
pawn_class = unreal.load_class(None, BW_PAWN)
hud_class = unreal.load_class(None, BW_HUD)
if not (mode_class and pawn_class and hud_class):
    fail('C++ BLACKWOOD classes missing. Rebuild the C++ project, restart Unreal and retry. '
         'Need BWGameMode, BWCharacter and BWHUD.')

assets = unreal.EditorAssetLibrary
if not assets.does_asset_exist(SOURCE_MAP):
    fail('World_Demo missing. Install into the project that contains StyleHex forest Content.')

if not assets.does_asset_exist(DESTINATION_MAP):
    info('Creating new level from template World_Demo...')
    assets.make_directory('/Game/Blackwood/Maps')
    if not level_system.new_level_from_template(DESTINATION_MAP, SOURCE_MAP):
        fail('Could not create BW_PlayableForest from World_Demo. Check Output Log.')
else:
    info('Playable map already exists; updating it.')
    if not level_system.load_level(DESTINATION_MAP):
        fail('Failed to open BW_PlayableForest.')

world_system = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem)
world = world_system.get_editor_world()
if not world:
    fail('Editor World is unavailable; do not run during PIE or Simulate.')

settings = world.get_world_settings()
old_mode = settings.get_editor_property('default_game_mode')
info('Previous map GameMode: {}'.format(old_mode))
settings.set_editor_property('default_game_mode', mode_class)
actual_mode = settings.get_editor_property('default_game_mode')
info('Current map GameMode: {}'.format(actual_mode))
if actual_mode != mode_class:
    fail('World Settings did not retain BWGameMode. Set it manually in World Settings.')

# Create a dedicated, tagged PlayerStart for BWGameMode::RestartPlayer.
# The game code traces down to the actual terrain and ensures a safe capsule height.
actors = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
found_spawn = False
for actor in actors.get_all_level_actors():
    if isinstance(actor, unreal.PlayerStart):
        try:
            if str(actor.get_editor_property('player_start_tag')) == BW_START_TAG:
                found_spawn = True
                break
        except Exception:
            pass

if not found_spawn:
    start = actors.spawn_actor_from_class(
        unreal.PlayerStart, unreal.Vector(0.0, 0.0, 1100.0), unreal.Rotator(0.0, 0.0, 0.0))
    if not start:
        fail('Could not place tagged PlayerStart in the map.')
    start.set_actor_label('BLACKWOOD_PlayerStart')
    start.set_editor_property('player_start_tag', unreal.Name(BW_START_TAG))
    info('Created BLACKWOOD_PlayerStart at X=0 Y=0 (runtime trace handles Z).')
else:
    info('Dedicated BLACKWOOD_PlayerStart already exists.')

if not level_system.save_current_level():
    fail('Could not save BW_PlayableForest. Check write permissions in Content/Blackwood/Maps.')

# Only change default level once the copy is saved. Retain all renderer and other settings.
project_dir = Path(__file__).resolve().parent.parent
ini_file = project_dir / 'Config' / 'DefaultEngine.ini'
if not ini_file.is_file():
    fail('DefaultEngine.ini not found at {}'.format(ini_file))
ini = ini_file.read_text(encoding='utf-8-sig')
for key in ('GameDefaultMap', 'EditorStartupMap'):
    pattern = r'(?m)^' + re.escape(key) + r'\s*=.*$'
    replacement = key + '=' + DESTINATION_MAP
    if re.search(pattern, ini):
        ini = re.sub(pattern, replacement, ini)
    else:
        section = '[/Script/EngineSettings.GameMapsSettings]'
        if section not in ini:
            ini = section + '\n' + replacement + '\n' + ini
        else:
            ini = ini.replace(section, section + '\n' + replacement, 1)
ini_file.write_text(ini, encoding='utf-8')

info('SUCCESS! A separate playable map is active: {}'.format(DESTINATION_MAP))
info('BWGameMode, BWCharacter and BWHUD are configured; map saved.')
info('Now press PLAY (not SIMULATE). If needed restart Unreal so map defaults refresh.')
