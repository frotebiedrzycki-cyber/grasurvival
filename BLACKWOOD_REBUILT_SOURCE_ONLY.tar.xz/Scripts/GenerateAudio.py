"""Generate original lightweight placeholder horror sound effects (public-domain-style synthetic tones).

Run: python Scripts/GenerateAudio.py
Then in UE Editor run Scripts/SetupEditorAssets.py to import WAV files.
This does NOT copy or use any third-party sound recordings.
"""
import math
import random
import struct
import wave
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / 'ExternalAssets'
OUT.mkdir(exist_ok=True)
RATE = 22050


def emit(filename, seconds, make_sample, seed=43):
    rng = random.Random(seed)
    n = int(RATE * seconds)
    with wave.open(str(OUT / filename), 'wb') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(RATE)
        frames = bytearray()
        for i in range(n):
            t = i / RATE
            value = max(-0.95, min(0.95, make_sample(t, seconds, rng)))
            frames.extend(struct.pack('<h', int(value * 32767)))
        wav.writeframes(frames)
    print(filename)


def short_sound(freq, duration=.16, noise=.18):
    def sample(t, end, rng):
        env = math.exp(-8*t/end)
        return env*(.26*math.sin(2*math.pi*freq*t)+noise*(2*rng.random()-1))
    return sample


emit('blackwood_flashlight_click.wav', .15, short_sound(1450, .15, .2))
emit('blackwood_pickup.wav', .17, short_sound(900, .17, .07))
emit('blackwood_attack.wav', .32, short_sound(160, .32, .24))
emit('blackwood_damage.wav', .48, short_sound(90, .48, .29))
emit('blackwood_radio_fixed.wav', .8, lambda t,e,r: .21*math.sin(2*math.pi*(440+300*t)*t)*math.exp(-t*2.5))
emit('blackwood_pistol_shot.wav', .35, lambda t,e,r: (.52*(2*r.random()-1)+.24*math.sin(2*math.pi*85*t))*math.exp(-18*t))
emit('blackwood_pistol_reload.wav', .7, lambda t,e,r: .17*math.sin(2*math.pi*1500*t)*math.exp(-17*(t%.25)))
wind = 0.0

def ambient(t,end,rng):
    global wind
    wind = .984*wind + .016*(2*rng.random()-1)
    swell = .75 + .25*math.sin(t*.4)
    return .25*swell*wind + .04*math.sin(2*math.pi*55*t)

emit('blackwood_night_ambience.wav', 24.0, ambient)
