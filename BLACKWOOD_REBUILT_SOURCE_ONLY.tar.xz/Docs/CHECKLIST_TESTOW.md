# BLACKWOOD v0.1 — lista testów do wykonania w Unreal Editor

## Pierwszy start
- [ ] Otworzenie `.uproject` w UE 5.8.x bez błędów UHT/kompilacji.
- [ ] Mapa Engine Entry + własny GameMode: po PIE postać pojawia się nad ziemią i opada na podłoże.
- [ ] W pierwszej sekundzie tworzą się drzewa, kamienie, ruina, radio i trzy zjawy.
- [ ] Po uruchomieniu `Scripts/SetupEditorAssets.py` pojawiają się zabarwione materiały, świecące oczy oraz dźwięk.

## Mechanika gracza
- [ ] WASD/mysz, Shift, Ctrl, Spacja działają bez przerywania kamery.
- [ ] Przytrzymanie Shift zużywa wytrzymałość, odpuszczenie ją przywraca.
- [ ] F włącza latarkę; podczas świecenia bateria spada, przy wyłączeniu powoli się ładuje.
- [ ] E na pniu/skalę/jagody/wodę zbiera przedmiot; gdy liczba użyć spadnie do zera, znika.
- [ ] TAB wyświetla ekwipunek z poprawnymi ilościami.
- [ ] 2/3 konsumują jedzenie/wodę i podnoszą głód/pragnienie.
- [ ] 1 po uzyskaniu 5 drewna i 3 kamieni tworzy ognisko i odejmuje materiały.
- [ ] Ognisko regeneruje powoli zdrowie i wytrzymałość, odstrasza zjawy.
- [ ] Cień rusza za graczem w promieniu 24m; latarka skierowana na przeciwnika spowalnia go.
- [ ] LPM trafia cień w zasięgu około 2,6m; trzy trafienia niszczą wroga.
- [ ] Przeciwnik w kontakcie odejmuje zdrowie, a po śmierci R odradza gracza.
- [ ] Po zebraniu 8 drewna i 5 kamieni E na radiu naprawia stację i aktualizuje HUD.

## Ograniczenia
- Bieżąca paczka nie była kompilowana w UnrealBuildTool, ponieważ Unreal Engine nie jest dostępny w środowisku generującym.
- Na tym etapie nie ma testu FPS, QA ścieżek AI, faktycznego inputu, materiałów lub skryptu importu w UE Editor.
