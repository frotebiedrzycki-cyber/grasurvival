# BLACKWOOD smoke tests (for UE5.8 Windows)

1. Open the project, choose **Play**. Confirm that `BLACKWOOD` main menu is displayed.
2. Click `GRAJ`. Confirm that camera is possessed by `ABWCharacter` and mouse look works.
3. Confirm WASD and collision; player remains above floor.
4. Confirm survival HUD displays health, hunger, thirst, stamina, battery.
5. Press TAB; confirm inventory overlay and resource counters; TAB closes it.
6. Press 1, 2, 3, 4, 5, 6, 7, 8, 9, 0; confirm selected hotbar highlight changes.
7. With slot 4, shoot (LMB) and reload (R); ammo changes on HUD.
8. Press F and verify flashlight visibility and battery use.
9. Gather wood/stone (E) and check inventory; spawn campfire from hotbar slot 9.
10. Fight a Whisper enemy; verify health and respawn (R) after death.
11. Press Esc: menu reopens; click `GRAJ` to resume.
12. Attempt Windows Development packaging and inspect the packaged EXE and Paks.

Attach Output Log with lines containing `BLACKWOOD_BOOT` if 1–3 fail.
