# Root-cause investigation and repair

## Verified source-level issues
1. v0.4 switched `GameDefaultMap` to third-party `World_Demo`. Unreal per-level `GameMode Override` takes precedence over `GlobalDefaultGameMode`. Our previous `ABWGameMode`, `ABWPlayerController`, pawn and HUD could therefore be bypassed.
2. Several separate installers overlaid copies of `BWCharacter`, `BWGameMode` and HUD. This created version-dependent behavior and made failures hard to diagnose.
3. Earlier iterations relied on Python editor scripts to alter an imported demonstration map and on manual clicks. The runtime boot should not require those tools.
4. Prior versions did not have a true main-menu widget; the HUD was intentionally drawn only when the controlled pawn was an `ABWCharacter`.
5. Defaulting to third person when the optional Nulla model was absent made the player appear invisible.

## Changes in the consolidated version
- Boot from known engine `Entry` map instead of imported `World_Demo`.
- Assign all gameplay classes inside `ABWGameMode`.
- Implement `ABWPlayerController::ShowMainMenu/StartGame` with an in-code UMG menu and possession validation.
- First-person camera by default; optional TPP after pressing V.
- Single assembled code base for pistol, TAB inventory and hotbar.

## Validation boundaries
No actual UBT/UHT/UE5.8 editor session is available in the authoring environment. Structural tests are useful, but cannot prove successful C++ compilation, cook/package, correct UI focus or runtime gameplay. Test with **Play**, not **Simulate**, in UE on Windows.

If startup fails, inspect **Window → Developer Tools → Output Log** and search `BLACKWOOD_BOOT`. Include the first C++ error (not just the last packaging failure line) in any bug report.
