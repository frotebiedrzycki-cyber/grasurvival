# BLACKWOOD v0.4 LITE (UE 5.8)

## Dlaczego LITE?
Paczka zawiera mapę StyleHex, modele, materiały i Whisper. Nie powiela ponad 300 MB przesłanych przez Ciebie animacji Revive & Downed Animation Pack, które nie zostały jeszcze podłączone do rozgrywki.

## Użycie
1. Rozpakuj ZIP do **osobnego folderu**.
2. Otwórz `BlackwoodSurvival.uproject`, wybierz Yes / Rebuild.
3. Mapa `World_Demo` jest domyślna. Wciśnij Play.
4. Jeśli brak audio, uruchom `Tools -> Execute Python Script -> Scripts/SetupEditorAssets.py`.

## Co zmieniono
- Domyślną mapą jest gotowa `World_Demo` zamiast pustej Entry.
- Generator nie przykrywa mapy wielkim szarym sześcianem i nie generuje prototypowego lasu na tej mapie.
- C++ dokłada punkty zbierania, radiostację, Whisperów i nocną mgłę.
- Pozycje postaci i surowców są dopasowywane do powierzchni mapy przez raycast.
- Pozostawiono starą generowaną mapę awaryjną, gdy ręcznie uruchomisz `Entry`.

## Ograniczenia
Nie mogłem kompilować i testować na UE 5.8 w tym środowisku. Animacje Revive są nadal osobną paczką i wymagają integracji z postacią oraz odpowiednim szkieletem. Mapa pochodzi ze stylizowanego pakietu, a nie fotorealistycznych modeli.
