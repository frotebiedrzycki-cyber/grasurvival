# BLACKWOOD — Changelog

## 0.6.0 — consolidated boot and inventory source

- Replaced third-party `World_Demo` startup map with engine `Entry` so no imported level GameMode can shadow the game.
- Added `ABWPlayerController` and `UBWMainMenuWidget` with in-code **GRAJ / WYJSCIE** menu, mouse focus and Esc toggle.
- Bound `ABWCharacter`, `ABWPlayerController` and `ABWHUD` together in `ABWGameMode`.
- Implemented default FPP viewpoint and optional V camera toggle, safe fall-to-ground spawn and pawn possession fallback.
- Preserved TAB inventory, 1–0 hotbar, 9 mm pistol with magazine/reserve, tools, flashlight and survival mechanics.
- Preserved StyleHex forest and Whisper skeletal asset integration, but only load asset packs when installed locally.
- Added diagnostics `BLACKWOOD_BOOT`, static verification and Windows packaging helper.
- Kept generated original placeholder sound effects, with a regeneration script for source-only clones.

Known limitation: Unreal Engine 5.8 is not installed in this authoring environment, so this is a structurally checked source snapshot, not a compiled/tested Windows executable.
