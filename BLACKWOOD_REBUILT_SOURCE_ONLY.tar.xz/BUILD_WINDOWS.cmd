@echo off
setlocal
set "PROJECT=%~dp0BlackwoodSurvival.uproject"
set "ENGINE_ROOT=E:\epic\UE_5.8"
if not exist "%ENGINE_ROOT%\Engine\Build\BatchFiles\RunUAT.bat" set "ENGINE_ROOT=C:\Program Files\Epic Games\UE_5.8"
if not exist "%ENGINE_ROOT%\Engine\Build\BatchFiles\RunUAT.bat" (
  echo [BLACKWOOD] Unreal Engine 5.8 not found.
  set /p ENGINE_ROOT=Enter your UE_5.8 installation folder: 
)
if not exist "%ENGINE_ROOT%\Engine\Build\BatchFiles\RunUAT.bat" (
  echo ERROR: RunUAT.bat missing; check ENGINE_ROOT.
  pause
  exit /b 1
)
echo [BLACKWOOD] Packaging Development/Win64 build...
call "%ENGINE_ROOT%\Engine\Build\BatchFiles\RunUAT.bat" BuildCookRun -project="%PROJECT%" -noP4 -platform=Win64 -clientconfig=Development -build -cook -stage -pak -archive -archivedirectory="%~dp0Packaged" -utf8output
if errorlevel 1 (
  echo [BLACKWOOD] Packaging FAILED. Open Output Log / UAT log to find the error.
  pause
  exit /b 1
)
echo [BLACKWOOD] Packaging finished: %~dp0Packaged
pause
